﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;

namespace BatteryCommunication
{
    public partial class Form1 : Form
    {
        List<byte> CommandList = new List<byte>();
        public Form1()
        {
            InitializeComponent();

            button1.BackColor = Color.GreenYellow;
            string[] PortNames = SerialPort.GetPortNames();
            COMPort.Items.AddRange(PortNames);
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(PortReply);
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == 0)
            {
                textBox2.Visible = false;
                //SendCommand("1");
            }
            else if(comboBox1.SelectedIndex == 1)
            {
                textBox2.Visible = false;
                CommandCombine(1);
            }
            else if(comboBox1.SelectedIndex == 2)
            {
                textBox2.Visible = true;
                textBox2.KeyDown += new KeyEventHandler(textBox2_keyDown);
            }
            else if(comboBox1.SelectedIndex == 3)
            {
                textBox2.Visible = false;
                CommandCombine(3);
            }
            else if(comboBox1.SelectedIndex == 4)
            {
                textBox2.Visible = true;
                textBox2.KeyDown += new KeyEventHandler(textBox2_keyDown);
            }
            else
            {
                textBox2.Visible = false;
                textBox1.Clear();
            }
        }
        private void PortReply(object sender,SerialDataReceivedEventArgs e)
        {
            byte[] PortData = new byte[50];
            serialPort1.Read(PortData, 0, 50);
            textBox1.Invoke(new EventHandler(delegate
            {
                textBox1.Clear();
                textBox1.AppendText(Convert.ToString(PortData));
            }));
            
        }
        private void textBox2_keyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                if(comboBox1.SelectedIndex == 2)
                {
                    CommandCombine(2);
                }
                else
                {
                    CommandCombine(4);
                }
                textBox2.Clear();
            }
        }

        private void COMPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.PortName = (string)COMPort.SelectedItem;
        }

        private void BaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.BaudRate = Convert.ToInt32(BaudRate.SelectedItem);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Connected)
            {
                serialPort1.Close();
                button1.Text = "Connect";
                button1.BackColor = Color.GreenYellow;
            }
            else
            {
                try
                {
                    if (COMPort.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else if (BaudRate.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else
                    {
                        serialPort1.Open();
                        button1.Text = "Disconnect";
                        button1.BackColor = Color.Pink;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Connecting failed");
                }
            }
        }
        private void SendCommand(byte[] Cmd)
        {
            if(Connected != false)
            {
                serialPort1.Write(Cmd,0,Cmd.Length);
            }
            else
            {
                MessageBox.Show("Not Connected!!!");
            }
        }
        public bool Connected
        {
            get
            {
                return serialPort1?.IsOpen ?? false;    //"?"讓後面變數變成可null,"??"是否為null,是=false,否=當下的值
            }
        }        
        private void CommandCombine(int item)
        {
            byte[] CommandListTransfer;
            switch (item)
            {
                case 1:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x51);
                    CommandList.Add(0x00);
                    CommandList.Add(0x51);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case 2:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x04);
                    CommandList.Add(0x50);
                    CommandList.Add(Convert.ToByte(textBox2.Text));
                    CommandList.Add((byte)(CalculateChkSum(CommandList, (char)(CommandList.Count - 3))));
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case 3:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x53);
                    CommandList.Add(0x00);
                    CommandList.Add(0x53);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case 4:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x07);
                    CommandList.Add(0x52);
                    CommandList.Add(Convert.ToByte(textBox2.Text));
                    CommandList.Add((byte)(CalculateChkSum(CommandList, (char)(CommandList.Count - 3))));
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
            }
        }
        private uint CalculateChkSum(List<byte> buf,char length)
        {
            buf = buf.GetRange(3, buf.Count - 3);
            uint ChkSum = 0;
            char ChkLen;
            int n;
            ChkLen = length;
            for (n = 0; n < ChkLen - 1; n += 2)
            {
                ChkSum += (uint)((buf[n] << 8) | buf[n + 1]);
            }
            if ((length & 0x01) == 1)
            {
                ChkSum = ChkSum ^ buf[length - 1];
            }
            return ChkSum;
        }
    }
}
