﻿namespace BatteryCommunication
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.COMPort = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.BaudRate = new System.Windows.Forms.ComboBox();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TBCButton = new System.Windows.Forms.Button();
            this.TBCBaudRate = new System.Windows.Forms.ComboBox();
            this.TBCCOMPort = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.TBCClear = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.TBCSetID = new System.Windows.Forms.Button();
            this.TBCSetIDTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TBCIDTrans = new System.Windows.Forms.TextBox();
            this.TBCID = new System.Windows.Forms.TextBox();
            this.TBCGetID = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.TBCClear2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.TBCSetSN = new System.Windows.Forms.Button();
            this.TBCSetSNTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TBCSNTrans = new System.Windows.Forms.TextBox();
            this.TBCSN = new System.Windows.Forms.TextBox();
            this.TBCGetSN = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TBCEF = new System.Windows.Forms.TextBox();
            this.TBCSF = new System.Windows.Forms.TextBox();
            this.TBCPV = new System.Windows.Forms.TextBox();
            this.TBCCD = new System.Windows.Forms.TextBox();
            this.TBCCE = new System.Windows.Forms.TextBox();
            this.TBCGetBAT = new System.Windows.Forms.Button();
            this.TBCUpdatePeriod = new System.Windows.Forms.Button();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(338, 209);
            this.textBox1.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.comboBox1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.comboBox1.Items.AddRange(new object[] {
            "BAT_Data",
            "Get_BAT_ID",
            "Set_ID",
            "Get_BAT_SerialNumber",
            "Set_SerialNumber",
            "Clear"});
            this.comboBox1.Location = new System.Drawing.Point(12, 261);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(338, 28);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.Location = new System.Drawing.Point(12, 295);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(338, 29);
            this.textBox2.TabIndex = 4;
            this.textBox2.Visible = false;
            // 
            // COMPort
            // 
            this.COMPort.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.COMPort.FormattingEnabled = true;
            this.COMPort.Location = new System.Drawing.Point(12, 231);
            this.COMPort.Name = "COMPort";
            this.COMPort.Size = new System.Drawing.Size(116, 24);
            this.COMPort.TabIndex = 5;
            this.COMPort.SelectedIndexChanged += new System.EventHandler(this.COMPort_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Location = new System.Drawing.Point(247, 231);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 24);
            this.button1.TabIndex = 6;
            this.button1.Text = "Connect";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BaudRate
            // 
            this.BaudRate.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.BaudRate.FormattingEnabled = true;
            this.BaudRate.Items.AddRange(new object[] {
            "115200"});
            this.BaudRate.Location = new System.Drawing.Point(134, 231);
            this.BaudRate.Name = "BaudRate";
            this.BaudRate.Size = new System.Drawing.Size(107, 24);
            this.BaudRate.TabIndex = 7;
            this.BaudRate.SelectedIndexChanged += new System.EventHandler(this.BaudRate_SelectedIndexChanged);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tabControl.Location = new System.Drawing.Point(356, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(373, 311);
            this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.TBCButton);
            this.tabPage1.Controls.Add(this.TBCBaudRate);
            this.tabPage1.Controls.Add(this.TBCCOMPort);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(365, 282);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Setting";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(21, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "BaudRate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(21, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "COMPort";
            // 
            // TBCButton
            // 
            this.TBCButton.Location = new System.Drawing.Point(94, 126);
            this.TBCButton.Name = "TBCButton";
            this.TBCButton.Size = new System.Drawing.Size(121, 23);
            this.TBCButton.TabIndex = 2;
            this.TBCButton.Text = "Connect";
            this.TBCButton.UseVisualStyleBackColor = true;
            this.TBCButton.Click += new System.EventHandler(this.TBCButton_Click);
            // 
            // TBCBaudRate
            // 
            this.TBCBaudRate.FormattingEnabled = true;
            this.TBCBaudRate.Items.AddRange(new object[] {
            "115200"});
            this.TBCBaudRate.Location = new System.Drawing.Point(94, 78);
            this.TBCBaudRate.Name = "TBCBaudRate";
            this.TBCBaudRate.Size = new System.Drawing.Size(121, 24);
            this.TBCBaudRate.TabIndex = 1;
            this.TBCBaudRate.SelectedIndexChanged += new System.EventHandler(this.TBCBaudRate_SelectedIndexChanged);
            // 
            // TBCCOMPort
            // 
            this.TBCCOMPort.FormattingEnabled = true;
            this.TBCCOMPort.Location = new System.Drawing.Point(94, 31);
            this.TBCCOMPort.Name = "TBCCOMPort";
            this.TBCCOMPort.Size = new System.Drawing.Size(121, 24);
            this.TBCCOMPort.TabIndex = 0;
            this.TBCCOMPort.SelectedIndexChanged += new System.EventHandler(this.TBCCOMPort_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.TBCClear);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.TBCSetID);
            this.tabPage2.Controls.Add(this.TBCSetIDTB);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.TBCIDTrans);
            this.tabPage2.Controls.Add(this.TBCID);
            this.tabPage2.Controls.Add(this.TBCGetID);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(365, 282);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ID";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // TBCClear
            // 
            this.TBCClear.Location = new System.Drawing.Point(262, 123);
            this.TBCClear.Name = "TBCClear";
            this.TBCClear.Size = new System.Drawing.Size(79, 28);
            this.TBCClear.TabIndex = 7;
            this.TBCClear.Text = "Clear";
            this.TBCClear.UseVisualStyleBackColor = true;
            this.TBCClear.Click += new System.EventHandler(this.TBCClear_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(25, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "New ID";
            // 
            // TBCSetID
            // 
            this.TBCSetID.Location = new System.Drawing.Point(266, 218);
            this.TBCSetID.Name = "TBCSetID";
            this.TBCSetID.Size = new System.Drawing.Size(75, 25);
            this.TBCSetID.TabIndex = 5;
            this.TBCSetID.Text = "Set ID";
            this.TBCSetID.UseVisualStyleBackColor = true;
            this.TBCSetID.Click += new System.EventHandler(this.TBCSetID_Click);
            // 
            // TBCSetIDTB
            // 
            this.TBCSetIDTB.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBCSetIDTB.Location = new System.Drawing.Point(84, 218);
            this.TBCSetIDTB.Name = "TBCSetIDTB";
            this.TBCSetIDTB.Size = new System.Drawing.Size(176, 25);
            this.TBCSetIDTB.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(22, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "ID";
            // 
            // TBCIDTrans
            // 
            this.TBCIDTrans.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBCIDTrans.Location = new System.Drawing.Point(54, 72);
            this.TBCIDTrans.Name = "TBCIDTrans";
            this.TBCIDTrans.ReadOnly = true;
            this.TBCIDTrans.Size = new System.Drawing.Size(287, 25);
            this.TBCIDTrans.TabIndex = 2;
            // 
            // TBCID
            // 
            this.TBCID.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBCID.Location = new System.Drawing.Point(22, 20);
            this.TBCID.Name = "TBCID";
            this.TBCID.ReadOnly = true;
            this.TBCID.Size = new System.Drawing.Size(319, 25);
            this.TBCID.TabIndex = 1;
            // 
            // TBCGetID
            // 
            this.TBCGetID.Location = new System.Drawing.Point(181, 123);
            this.TBCGetID.Name = "TBCGetID";
            this.TBCGetID.Size = new System.Drawing.Size(75, 28);
            this.TBCGetID.TabIndex = 0;
            this.TBCGetID.Text = "Get ID";
            this.TBCGetID.UseVisualStyleBackColor = true;
            this.TBCGetID.Click += new System.EventHandler(this.TBCGetID_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.TBCClear2);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.TBCSetSN);
            this.tabPage3.Controls.Add(this.TBCSetSNTB);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.TBCSNTrans);
            this.tabPage3.Controls.Add(this.TBCSN);
            this.tabPage3.Controls.Add(this.TBCGetSN);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(365, 282);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "SerialNumber";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // TBCClear2
            // 
            this.TBCClear2.Location = new System.Drawing.Point(262, 123);
            this.TBCClear2.Name = "TBCClear2";
            this.TBCClear2.Size = new System.Drawing.Size(79, 28);
            this.TBCClear2.TabIndex = 15;
            this.TBCClear2.Text = "Clear";
            this.TBCClear2.UseVisualStyleBackColor = true;
            this.TBCClear2.Click += new System.EventHandler(this.TBCClear2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(25, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "New SN";
            // 
            // TBCSetSN
            // 
            this.TBCSetSN.Location = new System.Drawing.Point(266, 218);
            this.TBCSetSN.Name = "TBCSetSN";
            this.TBCSetSN.Size = new System.Drawing.Size(75, 25);
            this.TBCSetSN.TabIndex = 13;
            this.TBCSetSN.Text = "Set SN";
            this.TBCSetSN.UseVisualStyleBackColor = true;
            this.TBCSetSN.Click += new System.EventHandler(this.TBCSetSN_Click);
            // 
            // TBCSetSNTB
            // 
            this.TBCSetSNTB.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBCSetSNTB.Location = new System.Drawing.Point(84, 218);
            this.TBCSetSNTB.Name = "TBCSetSNTB";
            this.TBCSetSNTB.Size = new System.Drawing.Size(176, 25);
            this.TBCSetSNTB.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(22, 74);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "SN";
            // 
            // TBCSNTrans
            // 
            this.TBCSNTrans.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBCSNTrans.Location = new System.Drawing.Point(54, 72);
            this.TBCSNTrans.Name = "TBCSNTrans";
            this.TBCSNTrans.ReadOnly = true;
            this.TBCSNTrans.Size = new System.Drawing.Size(287, 25);
            this.TBCSNTrans.TabIndex = 10;
            // 
            // TBCSN
            // 
            this.TBCSN.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TBCSN.Location = new System.Drawing.Point(22, 20);
            this.TBCSN.Name = "TBCSN";
            this.TBCSN.ReadOnly = true;
            this.TBCSN.Size = new System.Drawing.Size(319, 25);
            this.TBCSN.TabIndex = 9;
            // 
            // TBCGetSN
            // 
            this.TBCGetSN.Location = new System.Drawing.Point(181, 123);
            this.TBCGetSN.Name = "TBCGetSN";
            this.TBCGetSN.Size = new System.Drawing.Size(75, 28);
            this.TBCGetSN.TabIndex = 8;
            this.TBCGetSN.Text = "Get SN";
            this.TBCGetSN.UseVisualStyleBackColor = true;
            this.TBCGetSN.Click += new System.EventHandler(this.TBCGetSN_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.TBCUpdatePeriod);
            this.tabPage4.Controls.Add(this.TBCGetBAT);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.label8);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.TBCEF);
            this.tabPage4.Controls.Add(this.TBCSF);
            this.tabPage4.Controls.Add(this.TBCPV);
            this.tabPage4.Controls.Add(this.TBCCD);
            this.tabPage4.Controls.Add(this.TBCCE);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(365, 282);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Battery";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(288, 105);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 17);
            this.label14.TabIndex = 12;
            this.label14.Text = "V";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(288, 76);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 17);
            this.label13.TabIndex = 11;
            this.label13.Text = "A";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(288, 47);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(19, 17);
            this.label12.TabIndex = 10;
            this.label12.Text = "%";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(86, 163);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "Error";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(78, 134);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "Status";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(38, 105);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "Pack Voltage";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(34, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "Current Draw";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(17, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Charge Estimate";
            // 
            // TBCEF
            // 
            this.TBCEF.Location = new System.Drawing.Point(130, 161);
            this.TBCEF.Name = "TBCEF";
            this.TBCEF.ReadOnly = true;
            this.TBCEF.Size = new System.Drawing.Size(152, 23);
            this.TBCEF.TabIndex = 4;
            // 
            // TBCSF
            // 
            this.TBCSF.Location = new System.Drawing.Point(130, 132);
            this.TBCSF.Name = "TBCSF";
            this.TBCSF.ReadOnly = true;
            this.TBCSF.Size = new System.Drawing.Size(152, 23);
            this.TBCSF.TabIndex = 3;
            // 
            // TBCPV
            // 
            this.TBCPV.Location = new System.Drawing.Point(130, 103);
            this.TBCPV.Name = "TBCPV";
            this.TBCPV.ReadOnly = true;
            this.TBCPV.Size = new System.Drawing.Size(152, 23);
            this.TBCPV.TabIndex = 2;
            // 
            // TBCCD
            // 
            this.TBCCD.Location = new System.Drawing.Point(130, 74);
            this.TBCCD.Name = "TBCCD";
            this.TBCCD.ReadOnly = true;
            this.TBCCD.Size = new System.Drawing.Size(152, 23);
            this.TBCCD.TabIndex = 1;
            // 
            // TBCCE
            // 
            this.TBCCE.Location = new System.Drawing.Point(130, 45);
            this.TBCCE.Name = "TBCCE";
            this.TBCCE.ReadOnly = true;
            this.TBCCE.Size = new System.Drawing.Size(152, 23);
            this.TBCCE.TabIndex = 0;
            // 
            // TBCGetBAT
            // 
            this.TBCGetBAT.Location = new System.Drawing.Point(130, 214);
            this.TBCGetBAT.Name = "TBCGetBAT";
            this.TBCGetBAT.Size = new System.Drawing.Size(75, 23);
            this.TBCGetBAT.TabIndex = 13;
            this.TBCGetBAT.Text = "Get BAT";
            this.TBCGetBAT.UseVisualStyleBackColor = true;
            this.TBCGetBAT.Click += new System.EventHandler(this.TBCGetBAT_Click);
            // 
            // TBCUpdatePeriod
            // 
            this.TBCUpdatePeriod.Location = new System.Drawing.Point(211, 214);
            this.TBCUpdatePeriod.Name = "TBCUpdatePeriod";
            this.TBCUpdatePeriod.Size = new System.Drawing.Size(108, 23);
            this.TBCUpdatePeriod.TabIndex = 14;
            this.TBCUpdatePeriod.Text = "Update period";
            this.TBCUpdatePeriod.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 335);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.BaudRate);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.COMPort);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "BatteryCommunication";
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox COMPort;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox BaudRate;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button TBCButton;
        private System.Windows.Forms.ComboBox TBCBaudRate;
        private System.Windows.Forms.ComboBox TBCCOMPort;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button TBCSetID;
        private System.Windows.Forms.TextBox TBCSetIDTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TBCIDTrans;
        private System.Windows.Forms.TextBox TBCID;
        private System.Windows.Forms.Button TBCGetID;
        private System.Windows.Forms.Button TBCClear;
        private System.Windows.Forms.Button TBCClear2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button TBCSetSN;
        private System.Windows.Forms.TextBox TBCSetSNTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TBCSNTrans;
        private System.Windows.Forms.TextBox TBCSN;
        private System.Windows.Forms.Button TBCGetSN;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TBCEF;
        private System.Windows.Forms.TextBox TBCSF;
        private System.Windows.Forms.TextBox TBCPV;
        private System.Windows.Forms.TextBox TBCCD;
        private System.Windows.Forms.TextBox TBCCE;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button TBCUpdatePeriod;
        private System.Windows.Forms.Button TBCGetBAT;
    }
}

