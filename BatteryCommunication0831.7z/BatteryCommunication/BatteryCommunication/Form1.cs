﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace BatteryCommunication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            button1.BackColor = Color.GreenYellow;
            string[] PortNames = SerialPort.GetPortNames();
            COMPort.Items.AddRange(PortNames);
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(PortReply);
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == 0)
            {
                textBox2.Visible = false;
                SendCommand("1");
            }
            else if(comboBox1.SelectedIndex == 1)
            {
                textBox2.Visible = true;
                textBox2.KeyDown += new KeyEventHandler(textBox2_keyDown);
            }
            else
            {
                textBox2.Visible = false;
                textBox1.Clear();
            }
        }
        private void PortReply(object sender,SerialDataReceivedEventArgs e)
        {
            string PortData = serialPort1.ReadExisting();
            textBox1.Invoke(new EventHandler(delegate
            {
                textBox1.Clear();
                textBox1.AppendText(PortData);
            }));
            
        }
        private void textBox2_keyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                SendCommand(textBox2.Text);
                textBox2.Clear();
            }
        }

        private void COMPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.PortName = (string)COMPort.SelectedItem;
        }

        private void BaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.BaudRate = Convert.ToInt32(BaudRate.SelectedItem);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Connected)
            {
                serialPort1.Close();
                button1.Text = "Connect";
                button1.BackColor = Color.GreenYellow;
            }
            else
            {
                try
                {
                    if (COMPort.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else if (BaudRate.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else
                    {
                        serialPort1.Open();
                        button1.Text = "Disconnect";
                        button1.BackColor = Color.Pink;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Connecting failed");
                }
            }
        }
        private void SendCommand(string Cmd)
        {
            if(Connected != false)
            {
                serialPort1.Write(Cmd);
            }
            else
            {
                MessageBox.Show("Not Connected!!!");
            }
        }
        public bool Connected
        {
            get
            {
                return serialPort1?.IsOpen ?? false;    //"?"讓後面變數變成可null,"??"是否為null,是=false,否=當下的值
            }
        }
    }
}
