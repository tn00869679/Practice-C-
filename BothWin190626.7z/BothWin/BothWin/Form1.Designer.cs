﻿namespace BothWin
{
    partial class frmBothWin
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.NUD1_1 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_2 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_3 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_4 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_5 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_6 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_7 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_8 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_9 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_10 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_11 = new System.Windows.Forms.NumericUpDown();
            this.NUD1_12 = new System.Windows.Forms.NumericUpDown();
            this.lbl1 = new System.Windows.Forms.Label();
            this.NUD2_1 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_2 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_3 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_4 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_5 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_6 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_7 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_8 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_9 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_10 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_11 = new System.Windows.Forms.NumericUpDown();
            this.NUD2_12 = new System.Windows.Forms.NumericUpDown();
            this.lbl2 = new System.Windows.Forms.Label();
            this.NUD3_1 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_2 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_3 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_4 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_5 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_6 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_7 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_8 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_9 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_10 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_11 = new System.Windows.Forms.NumericUpDown();
            this.NUD3_12 = new System.Windows.Forms.NumericUpDown();
            this.lbl3 = new System.Windows.Forms.Label();
            this.NUD4_1 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_2 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_3 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_4 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_5 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_6 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_7 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_8 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_9 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_10 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_11 = new System.Windows.Forms.NumericUpDown();
            this.NUD4_12 = new System.Windows.Forms.NumericUpDown();
            this.lbl4 = new System.Windows.Forms.Label();
            this.NUD5_1 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_2 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_3 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_4 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_5 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_6 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_7 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_8 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_9 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_10 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_11 = new System.Windows.Forms.NumericUpDown();
            this.NUD5_12 = new System.Windows.Forms.NumericUpDown();
            this.lbl5 = new System.Windows.Forms.Label();
            this.btnCCT = new System.Windows.Forms.Button();
            this.txt_Ans1 = new System.Windows.Forms.TextBox();
            this.txt_Ans2 = new System.Windows.Forms.TextBox();
            this.txt_Ans3 = new System.Windows.Forms.TextBox();
            this.txt_Ans4 = new System.Windows.Forms.TextBox();
            this.txt_Ans5 = new System.Windows.Forms.TextBox();
            this.txt_Ans6 = new System.Windows.Forms.TextBox();
            this.txt_Ans7 = new System.Windows.Forms.TextBox();
            this.txt_Ans8 = new System.Windows.Forms.TextBox();
            this.txt_Ans9 = new System.Windows.Forms.TextBox();
            this.txt_Ans10 = new System.Windows.Forms.TextBox();
            this.txt_Ans11 = new System.Windows.Forms.TextBox();
            this.txt_Ans12 = new System.Windows.Forms.TextBox();
            this.lbl_Ans = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_12)).BeginInit();
            this.SuspendLayout();
            // 
            // NUD1_1
            // 
            this.NUD1_1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_1.Location = new System.Drawing.Point(53, 12);
            this.NUD1_1.Name = "NUD1_1";
            this.NUD1_1.Size = new System.Drawing.Size(38, 25);
            this.NUD1_1.TabIndex = 0;
            // 
            // NUD1_2
            // 
            this.NUD1_2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_2.Location = new System.Drawing.Point(97, 12);
            this.NUD1_2.Name = "NUD1_2";
            this.NUD1_2.Size = new System.Drawing.Size(38, 25);
            this.NUD1_2.TabIndex = 0;
            // 
            // NUD1_3
            // 
            this.NUD1_3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_3.Location = new System.Drawing.Point(141, 12);
            this.NUD1_3.Name = "NUD1_3";
            this.NUD1_3.Size = new System.Drawing.Size(38, 25);
            this.NUD1_3.TabIndex = 0;
            // 
            // NUD1_4
            // 
            this.NUD1_4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_4.Location = new System.Drawing.Point(185, 12);
            this.NUD1_4.Name = "NUD1_4";
            this.NUD1_4.Size = new System.Drawing.Size(38, 25);
            this.NUD1_4.TabIndex = 0;
            // 
            // NUD1_5
            // 
            this.NUD1_5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_5.Location = new System.Drawing.Point(229, 12);
            this.NUD1_5.Name = "NUD1_5";
            this.NUD1_5.Size = new System.Drawing.Size(38, 25);
            this.NUD1_5.TabIndex = 0;
            // 
            // NUD1_6
            // 
            this.NUD1_6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_6.Location = new System.Drawing.Point(273, 12);
            this.NUD1_6.Name = "NUD1_6";
            this.NUD1_6.Size = new System.Drawing.Size(38, 25);
            this.NUD1_6.TabIndex = 0;
            // 
            // NUD1_7
            // 
            this.NUD1_7.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_7.Location = new System.Drawing.Point(317, 12);
            this.NUD1_7.Name = "NUD1_7";
            this.NUD1_7.Size = new System.Drawing.Size(38, 25);
            this.NUD1_7.TabIndex = 0;
            // 
            // NUD1_8
            // 
            this.NUD1_8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_8.Location = new System.Drawing.Point(361, 12);
            this.NUD1_8.Name = "NUD1_8";
            this.NUD1_8.Size = new System.Drawing.Size(38, 25);
            this.NUD1_8.TabIndex = 0;
            // 
            // NUD1_9
            // 
            this.NUD1_9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_9.Location = new System.Drawing.Point(405, 12);
            this.NUD1_9.Name = "NUD1_9";
            this.NUD1_9.Size = new System.Drawing.Size(38, 25);
            this.NUD1_9.TabIndex = 0;
            // 
            // NUD1_10
            // 
            this.NUD1_10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_10.Location = new System.Drawing.Point(449, 12);
            this.NUD1_10.Name = "NUD1_10";
            this.NUD1_10.Size = new System.Drawing.Size(38, 25);
            this.NUD1_10.TabIndex = 0;
            // 
            // NUD1_11
            // 
            this.NUD1_11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_11.Location = new System.Drawing.Point(493, 12);
            this.NUD1_11.Name = "NUD1_11";
            this.NUD1_11.Size = new System.Drawing.Size(38, 25);
            this.NUD1_11.TabIndex = 0;
            // 
            // NUD1_12
            // 
            this.NUD1_12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD1_12.Location = new System.Drawing.Point(537, 12);
            this.NUD1_12.Name = "NUD1_12";
            this.NUD1_12.Size = new System.Drawing.Size(38, 25);
            this.NUD1_12.TabIndex = 0;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl1.Location = new System.Drawing.Point(5, 14);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(42, 17);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "第1組";
            // 
            // NUD2_1
            // 
            this.NUD2_1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_1.Location = new System.Drawing.Point(53, 43);
            this.NUD2_1.Name = "NUD2_1";
            this.NUD2_1.Size = new System.Drawing.Size(38, 25);
            this.NUD2_1.TabIndex = 0;
            // 
            // NUD2_2
            // 
            this.NUD2_2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_2.Location = new System.Drawing.Point(97, 43);
            this.NUD2_2.Name = "NUD2_2";
            this.NUD2_2.Size = new System.Drawing.Size(38, 25);
            this.NUD2_2.TabIndex = 0;
            // 
            // NUD2_3
            // 
            this.NUD2_3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_3.Location = new System.Drawing.Point(141, 43);
            this.NUD2_3.Name = "NUD2_3";
            this.NUD2_3.Size = new System.Drawing.Size(38, 25);
            this.NUD2_3.TabIndex = 0;
            // 
            // NUD2_4
            // 
            this.NUD2_4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_4.Location = new System.Drawing.Point(185, 43);
            this.NUD2_4.Name = "NUD2_4";
            this.NUD2_4.Size = new System.Drawing.Size(38, 25);
            this.NUD2_4.TabIndex = 0;
            // 
            // NUD2_5
            // 
            this.NUD2_5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_5.Location = new System.Drawing.Point(229, 43);
            this.NUD2_5.Name = "NUD2_5";
            this.NUD2_5.Size = new System.Drawing.Size(38, 25);
            this.NUD2_5.TabIndex = 0;
            // 
            // NUD2_6
            // 
            this.NUD2_6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_6.Location = new System.Drawing.Point(273, 43);
            this.NUD2_6.Name = "NUD2_6";
            this.NUD2_6.Size = new System.Drawing.Size(38, 25);
            this.NUD2_6.TabIndex = 0;
            // 
            // NUD2_7
            // 
            this.NUD2_7.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_7.Location = new System.Drawing.Point(317, 43);
            this.NUD2_7.Name = "NUD2_7";
            this.NUD2_7.Size = new System.Drawing.Size(38, 25);
            this.NUD2_7.TabIndex = 0;
            // 
            // NUD2_8
            // 
            this.NUD2_8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_8.Location = new System.Drawing.Point(361, 43);
            this.NUD2_8.Name = "NUD2_8";
            this.NUD2_8.Size = new System.Drawing.Size(38, 25);
            this.NUD2_8.TabIndex = 0;
            // 
            // NUD2_9
            // 
            this.NUD2_9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_9.Location = new System.Drawing.Point(405, 43);
            this.NUD2_9.Name = "NUD2_9";
            this.NUD2_9.Size = new System.Drawing.Size(38, 25);
            this.NUD2_9.TabIndex = 0;
            // 
            // NUD2_10
            // 
            this.NUD2_10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_10.Location = new System.Drawing.Point(449, 43);
            this.NUD2_10.Name = "NUD2_10";
            this.NUD2_10.Size = new System.Drawing.Size(38, 25);
            this.NUD2_10.TabIndex = 0;
            // 
            // NUD2_11
            // 
            this.NUD2_11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_11.Location = new System.Drawing.Point(493, 43);
            this.NUD2_11.Name = "NUD2_11";
            this.NUD2_11.Size = new System.Drawing.Size(38, 25);
            this.NUD2_11.TabIndex = 0;
            // 
            // NUD2_12
            // 
            this.NUD2_12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD2_12.Location = new System.Drawing.Point(537, 43);
            this.NUD2_12.Name = "NUD2_12";
            this.NUD2_12.Size = new System.Drawing.Size(38, 25);
            this.NUD2_12.TabIndex = 0;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl2.Location = new System.Drawing.Point(5, 45);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(42, 17);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "第2組";
            // 
            // NUD3_1
            // 
            this.NUD3_1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_1.Location = new System.Drawing.Point(53, 74);
            this.NUD3_1.Name = "NUD3_1";
            this.NUD3_1.Size = new System.Drawing.Size(38, 25);
            this.NUD3_1.TabIndex = 0;
            // 
            // NUD3_2
            // 
            this.NUD3_2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_2.Location = new System.Drawing.Point(97, 74);
            this.NUD3_2.Name = "NUD3_2";
            this.NUD3_2.Size = new System.Drawing.Size(38, 25);
            this.NUD3_2.TabIndex = 0;
            // 
            // NUD3_3
            // 
            this.NUD3_3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_3.Location = new System.Drawing.Point(141, 74);
            this.NUD3_3.Name = "NUD3_3";
            this.NUD3_3.Size = new System.Drawing.Size(38, 25);
            this.NUD3_3.TabIndex = 0;
            // 
            // NUD3_4
            // 
            this.NUD3_4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_4.Location = new System.Drawing.Point(185, 74);
            this.NUD3_4.Name = "NUD3_4";
            this.NUD3_4.Size = new System.Drawing.Size(38, 25);
            this.NUD3_4.TabIndex = 0;
            // 
            // NUD3_5
            // 
            this.NUD3_5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_5.Location = new System.Drawing.Point(229, 74);
            this.NUD3_5.Name = "NUD3_5";
            this.NUD3_5.Size = new System.Drawing.Size(38, 25);
            this.NUD3_5.TabIndex = 0;
            // 
            // NUD3_6
            // 
            this.NUD3_6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_6.Location = new System.Drawing.Point(273, 74);
            this.NUD3_6.Name = "NUD3_6";
            this.NUD3_6.Size = new System.Drawing.Size(38, 25);
            this.NUD3_6.TabIndex = 0;
            // 
            // NUD3_7
            // 
            this.NUD3_7.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_7.Location = new System.Drawing.Point(317, 74);
            this.NUD3_7.Name = "NUD3_7";
            this.NUD3_7.Size = new System.Drawing.Size(38, 25);
            this.NUD3_7.TabIndex = 0;
            // 
            // NUD3_8
            // 
            this.NUD3_8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_8.Location = new System.Drawing.Point(361, 74);
            this.NUD3_8.Name = "NUD3_8";
            this.NUD3_8.Size = new System.Drawing.Size(38, 25);
            this.NUD3_8.TabIndex = 0;
            // 
            // NUD3_9
            // 
            this.NUD3_9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_9.Location = new System.Drawing.Point(405, 74);
            this.NUD3_9.Name = "NUD3_9";
            this.NUD3_9.Size = new System.Drawing.Size(38, 25);
            this.NUD3_9.TabIndex = 0;
            // 
            // NUD3_10
            // 
            this.NUD3_10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_10.Location = new System.Drawing.Point(449, 74);
            this.NUD3_10.Name = "NUD3_10";
            this.NUD3_10.Size = new System.Drawing.Size(38, 25);
            this.NUD3_10.TabIndex = 0;
            // 
            // NUD3_11
            // 
            this.NUD3_11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_11.Location = new System.Drawing.Point(493, 74);
            this.NUD3_11.Name = "NUD3_11";
            this.NUD3_11.Size = new System.Drawing.Size(38, 25);
            this.NUD3_11.TabIndex = 0;
            // 
            // NUD3_12
            // 
            this.NUD3_12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD3_12.Location = new System.Drawing.Point(537, 74);
            this.NUD3_12.Name = "NUD3_12";
            this.NUD3_12.Size = new System.Drawing.Size(38, 25);
            this.NUD3_12.TabIndex = 0;
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl3.Location = new System.Drawing.Point(5, 76);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(42, 17);
            this.lbl3.TabIndex = 1;
            this.lbl3.Text = "第3組";
            // 
            // NUD4_1
            // 
            this.NUD4_1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_1.Location = new System.Drawing.Point(53, 105);
            this.NUD4_1.Name = "NUD4_1";
            this.NUD4_1.Size = new System.Drawing.Size(38, 25);
            this.NUD4_1.TabIndex = 0;
            // 
            // NUD4_2
            // 
            this.NUD4_2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_2.Location = new System.Drawing.Point(97, 105);
            this.NUD4_2.Name = "NUD4_2";
            this.NUD4_2.Size = new System.Drawing.Size(38, 25);
            this.NUD4_2.TabIndex = 0;
            // 
            // NUD4_3
            // 
            this.NUD4_3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_3.Location = new System.Drawing.Point(141, 105);
            this.NUD4_3.Name = "NUD4_3";
            this.NUD4_3.Size = new System.Drawing.Size(38, 25);
            this.NUD4_3.TabIndex = 0;
            // 
            // NUD4_4
            // 
            this.NUD4_4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_4.Location = new System.Drawing.Point(185, 105);
            this.NUD4_4.Name = "NUD4_4";
            this.NUD4_4.Size = new System.Drawing.Size(38, 25);
            this.NUD4_4.TabIndex = 0;
            // 
            // NUD4_5
            // 
            this.NUD4_5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_5.Location = new System.Drawing.Point(229, 105);
            this.NUD4_5.Name = "NUD4_5";
            this.NUD4_5.Size = new System.Drawing.Size(38, 25);
            this.NUD4_5.TabIndex = 0;
            // 
            // NUD4_6
            // 
            this.NUD4_6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_6.Location = new System.Drawing.Point(273, 105);
            this.NUD4_6.Name = "NUD4_6";
            this.NUD4_6.Size = new System.Drawing.Size(38, 25);
            this.NUD4_6.TabIndex = 0;
            // 
            // NUD4_7
            // 
            this.NUD4_7.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_7.Location = new System.Drawing.Point(317, 105);
            this.NUD4_7.Name = "NUD4_7";
            this.NUD4_7.Size = new System.Drawing.Size(38, 25);
            this.NUD4_7.TabIndex = 0;
            // 
            // NUD4_8
            // 
            this.NUD4_8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_8.Location = new System.Drawing.Point(361, 105);
            this.NUD4_8.Name = "NUD4_8";
            this.NUD4_8.Size = new System.Drawing.Size(38, 25);
            this.NUD4_8.TabIndex = 0;
            // 
            // NUD4_9
            // 
            this.NUD4_9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_9.Location = new System.Drawing.Point(405, 105);
            this.NUD4_9.Name = "NUD4_9";
            this.NUD4_9.Size = new System.Drawing.Size(38, 25);
            this.NUD4_9.TabIndex = 0;
            // 
            // NUD4_10
            // 
            this.NUD4_10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_10.Location = new System.Drawing.Point(449, 105);
            this.NUD4_10.Name = "NUD4_10";
            this.NUD4_10.Size = new System.Drawing.Size(38, 25);
            this.NUD4_10.TabIndex = 0;
            // 
            // NUD4_11
            // 
            this.NUD4_11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_11.Location = new System.Drawing.Point(493, 105);
            this.NUD4_11.Name = "NUD4_11";
            this.NUD4_11.Size = new System.Drawing.Size(38, 25);
            this.NUD4_11.TabIndex = 0;
            // 
            // NUD4_12
            // 
            this.NUD4_12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD4_12.Location = new System.Drawing.Point(537, 105);
            this.NUD4_12.Name = "NUD4_12";
            this.NUD4_12.Size = new System.Drawing.Size(38, 25);
            this.NUD4_12.TabIndex = 0;
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl4.Location = new System.Drawing.Point(5, 107);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(42, 17);
            this.lbl4.TabIndex = 1;
            this.lbl4.Text = "第4組";
            // 
            // NUD5_1
            // 
            this.NUD5_1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_1.Location = new System.Drawing.Point(53, 136);
            this.NUD5_1.Name = "NUD5_1";
            this.NUD5_1.Size = new System.Drawing.Size(38, 25);
            this.NUD5_1.TabIndex = 0;
            // 
            // NUD5_2
            // 
            this.NUD5_2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_2.Location = new System.Drawing.Point(97, 136);
            this.NUD5_2.Name = "NUD5_2";
            this.NUD5_2.Size = new System.Drawing.Size(38, 25);
            this.NUD5_2.TabIndex = 0;
            // 
            // NUD5_3
            // 
            this.NUD5_3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_3.Location = new System.Drawing.Point(141, 136);
            this.NUD5_3.Name = "NUD5_3";
            this.NUD5_3.Size = new System.Drawing.Size(38, 25);
            this.NUD5_3.TabIndex = 0;
            // 
            // NUD5_4
            // 
            this.NUD5_4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_4.Location = new System.Drawing.Point(185, 136);
            this.NUD5_4.Name = "NUD5_4";
            this.NUD5_4.Size = new System.Drawing.Size(38, 25);
            this.NUD5_4.TabIndex = 0;
            // 
            // NUD5_5
            // 
            this.NUD5_5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_5.Location = new System.Drawing.Point(229, 136);
            this.NUD5_5.Name = "NUD5_5";
            this.NUD5_5.Size = new System.Drawing.Size(38, 25);
            this.NUD5_5.TabIndex = 0;
            // 
            // NUD5_6
            // 
            this.NUD5_6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_6.Location = new System.Drawing.Point(273, 136);
            this.NUD5_6.Name = "NUD5_6";
            this.NUD5_6.Size = new System.Drawing.Size(38, 25);
            this.NUD5_6.TabIndex = 0;
            // 
            // NUD5_7
            // 
            this.NUD5_7.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_7.Location = new System.Drawing.Point(317, 136);
            this.NUD5_7.Name = "NUD5_7";
            this.NUD5_7.Size = new System.Drawing.Size(38, 25);
            this.NUD5_7.TabIndex = 0;
            // 
            // NUD5_8
            // 
            this.NUD5_8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_8.Location = new System.Drawing.Point(361, 136);
            this.NUD5_8.Name = "NUD5_8";
            this.NUD5_8.Size = new System.Drawing.Size(38, 25);
            this.NUD5_8.TabIndex = 0;
            // 
            // NUD5_9
            // 
            this.NUD5_9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_9.Location = new System.Drawing.Point(405, 136);
            this.NUD5_9.Name = "NUD5_9";
            this.NUD5_9.Size = new System.Drawing.Size(38, 25);
            this.NUD5_9.TabIndex = 0;
            // 
            // NUD5_10
            // 
            this.NUD5_10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_10.Location = new System.Drawing.Point(449, 136);
            this.NUD5_10.Name = "NUD5_10";
            this.NUD5_10.Size = new System.Drawing.Size(38, 25);
            this.NUD5_10.TabIndex = 0;
            // 
            // NUD5_11
            // 
            this.NUD5_11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_11.Location = new System.Drawing.Point(493, 136);
            this.NUD5_11.Name = "NUD5_11";
            this.NUD5_11.Size = new System.Drawing.Size(38, 25);
            this.NUD5_11.TabIndex = 0;
            // 
            // NUD5_12
            // 
            this.NUD5_12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.NUD5_12.Location = new System.Drawing.Point(537, 136);
            this.NUD5_12.Name = "NUD5_12";
            this.NUD5_12.Size = new System.Drawing.Size(38, 25);
            this.NUD5_12.TabIndex = 0;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl5.Location = new System.Drawing.Point(5, 138);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(42, 17);
            this.lbl5.TabIndex = 1;
            this.lbl5.Text = "第5組";
            // 
            // btnCCT
            // 
            this.btnCCT.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnCCT.Location = new System.Drawing.Point(229, 177);
            this.btnCCT.Name = "btnCCT";
            this.btnCCT.Size = new System.Drawing.Size(126, 40);
            this.btnCCT.TabIndex = 2;
            this.btnCCT.Text = "計算";
            this.btnCCT.UseVisualStyleBackColor = true;
            // 
            // txt_Ans1
            // 
            this.txt_Ans1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans1.Location = new System.Drawing.Point(53, 224);
            this.txt_Ans1.Name = "txt_Ans1";
            this.txt_Ans1.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans1.TabIndex = 3;
            // 
            // txt_Ans2
            // 
            this.txt_Ans2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans2.Location = new System.Drawing.Point(97, 224);
            this.txt_Ans2.Name = "txt_Ans2";
            this.txt_Ans2.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans2.TabIndex = 3;
            // 
            // txt_Ans3
            // 
            this.txt_Ans3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans3.Location = new System.Drawing.Point(141, 224);
            this.txt_Ans3.Name = "txt_Ans3";
            this.txt_Ans3.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans3.TabIndex = 3;
            // 
            // txt_Ans4
            // 
            this.txt_Ans4.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans4.Location = new System.Drawing.Point(185, 224);
            this.txt_Ans4.Name = "txt_Ans4";
            this.txt_Ans4.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans4.TabIndex = 3;
            // 
            // txt_Ans5
            // 
            this.txt_Ans5.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans5.Location = new System.Drawing.Point(229, 224);
            this.txt_Ans5.Name = "txt_Ans5";
            this.txt_Ans5.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans5.TabIndex = 3;
            // 
            // txt_Ans6
            // 
            this.txt_Ans6.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans6.Location = new System.Drawing.Point(273, 224);
            this.txt_Ans6.Name = "txt_Ans6";
            this.txt_Ans6.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans6.TabIndex = 3;
            // 
            // txt_Ans7
            // 
            this.txt_Ans7.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans7.Location = new System.Drawing.Point(317, 224);
            this.txt_Ans7.Name = "txt_Ans7";
            this.txt_Ans7.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans7.TabIndex = 3;
            // 
            // txt_Ans8
            // 
            this.txt_Ans8.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans8.Location = new System.Drawing.Point(361, 224);
            this.txt_Ans8.Name = "txt_Ans8";
            this.txt_Ans8.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans8.TabIndex = 3;
            // 
            // txt_Ans9
            // 
            this.txt_Ans9.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans9.Location = new System.Drawing.Point(405, 224);
            this.txt_Ans9.Name = "txt_Ans9";
            this.txt_Ans9.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans9.TabIndex = 3;
            // 
            // txt_Ans10
            // 
            this.txt_Ans10.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans10.Location = new System.Drawing.Point(449, 224);
            this.txt_Ans10.Name = "txt_Ans10";
            this.txt_Ans10.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans10.TabIndex = 3;
            // 
            // txt_Ans11
            // 
            this.txt_Ans11.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans11.Location = new System.Drawing.Point(493, 224);
            this.txt_Ans11.Name = "txt_Ans11";
            this.txt_Ans11.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans11.TabIndex = 3;
            // 
            // txt_Ans12
            // 
            this.txt_Ans12.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt_Ans12.Location = new System.Drawing.Point(537, 224);
            this.txt_Ans12.Name = "txt_Ans12";
            this.txt_Ans12.Size = new System.Drawing.Size(38, 25);
            this.txt_Ans12.TabIndex = 3;
            // 
            // lbl_Ans
            // 
            this.lbl_Ans.AutoSize = true;
            this.lbl_Ans.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_Ans.Location = new System.Drawing.Point(12, 227);
            this.lbl_Ans.Name = "lbl_Ans";
            this.lbl_Ans.Size = new System.Drawing.Size(31, 17);
            this.lbl_Ans.TabIndex = 1;
            this.lbl_Ans.Text = "Ans";
            // 
            // frmBothWin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 307);
            this.Controls.Add(this.txt_Ans12);
            this.Controls.Add(this.txt_Ans11);
            this.Controls.Add(this.txt_Ans10);
            this.Controls.Add(this.txt_Ans9);
            this.Controls.Add(this.txt_Ans8);
            this.Controls.Add(this.txt_Ans7);
            this.Controls.Add(this.txt_Ans6);
            this.Controls.Add(this.txt_Ans5);
            this.Controls.Add(this.txt_Ans4);
            this.Controls.Add(this.txt_Ans3);
            this.Controls.Add(this.txt_Ans2);
            this.Controls.Add(this.txt_Ans1);
            this.Controls.Add(this.btnCCT);
            this.Controls.Add(this.lbl_Ans);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.NUD5_12);
            this.Controls.Add(this.NUD4_12);
            this.Controls.Add(this.NUD3_12);
            this.Controls.Add(this.NUD2_12);
            this.Controls.Add(this.NUD1_12);
            this.Controls.Add(this.NUD5_11);
            this.Controls.Add(this.NUD4_11);
            this.Controls.Add(this.NUD3_11);
            this.Controls.Add(this.NUD2_11);
            this.Controls.Add(this.NUD1_11);
            this.Controls.Add(this.NUD5_10);
            this.Controls.Add(this.NUD4_10);
            this.Controls.Add(this.NUD3_10);
            this.Controls.Add(this.NUD2_10);
            this.Controls.Add(this.NUD1_10);
            this.Controls.Add(this.NUD5_9);
            this.Controls.Add(this.NUD4_9);
            this.Controls.Add(this.NUD3_9);
            this.Controls.Add(this.NUD2_9);
            this.Controls.Add(this.NUD1_9);
            this.Controls.Add(this.NUD5_8);
            this.Controls.Add(this.NUD4_8);
            this.Controls.Add(this.NUD3_8);
            this.Controls.Add(this.NUD2_8);
            this.Controls.Add(this.NUD1_8);
            this.Controls.Add(this.NUD5_7);
            this.Controls.Add(this.NUD4_7);
            this.Controls.Add(this.NUD3_7);
            this.Controls.Add(this.NUD2_7);
            this.Controls.Add(this.NUD1_7);
            this.Controls.Add(this.NUD5_6);
            this.Controls.Add(this.NUD4_6);
            this.Controls.Add(this.NUD3_6);
            this.Controls.Add(this.NUD2_6);
            this.Controls.Add(this.NUD1_6);
            this.Controls.Add(this.NUD5_5);
            this.Controls.Add(this.NUD4_5);
            this.Controls.Add(this.NUD3_5);
            this.Controls.Add(this.NUD2_5);
            this.Controls.Add(this.NUD1_5);
            this.Controls.Add(this.NUD5_4);
            this.Controls.Add(this.NUD4_4);
            this.Controls.Add(this.NUD3_4);
            this.Controls.Add(this.NUD2_4);
            this.Controls.Add(this.NUD1_4);
            this.Controls.Add(this.NUD5_3);
            this.Controls.Add(this.NUD4_3);
            this.Controls.Add(this.NUD3_3);
            this.Controls.Add(this.NUD2_3);
            this.Controls.Add(this.NUD1_3);
            this.Controls.Add(this.NUD5_2);
            this.Controls.Add(this.NUD4_2);
            this.Controls.Add(this.NUD3_2);
            this.Controls.Add(this.NUD2_2);
            this.Controls.Add(this.NUD1_2);
            this.Controls.Add(this.NUD5_1);
            this.Controls.Add(this.NUD4_1);
            this.Controls.Add(this.NUD3_1);
            this.Controls.Add(this.NUD2_1);
            this.Controls.Add(this.NUD1_1);
            this.Name = "frmBothWin";
            this.Text = "Both Win";
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD5_12)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown NUD1_1;
        private System.Windows.Forms.NumericUpDown NUD1_2;
        private System.Windows.Forms.NumericUpDown NUD1_3;
        private System.Windows.Forms.NumericUpDown NUD1_4;
        private System.Windows.Forms.NumericUpDown NUD1_5;
        private System.Windows.Forms.NumericUpDown NUD1_6;
        private System.Windows.Forms.NumericUpDown NUD1_7;
        private System.Windows.Forms.NumericUpDown NUD1_8;
        private System.Windows.Forms.NumericUpDown NUD1_9;
        private System.Windows.Forms.NumericUpDown NUD1_10;
        private System.Windows.Forms.NumericUpDown NUD1_11;
        private System.Windows.Forms.NumericUpDown NUD1_12;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.NumericUpDown NUD2_1;
        private System.Windows.Forms.NumericUpDown NUD2_2;
        private System.Windows.Forms.NumericUpDown NUD2_3;
        private System.Windows.Forms.NumericUpDown NUD2_4;
        private System.Windows.Forms.NumericUpDown NUD2_5;
        private System.Windows.Forms.NumericUpDown NUD2_6;
        private System.Windows.Forms.NumericUpDown NUD2_7;
        private System.Windows.Forms.NumericUpDown NUD2_8;
        private System.Windows.Forms.NumericUpDown NUD2_9;
        private System.Windows.Forms.NumericUpDown NUD2_10;
        private System.Windows.Forms.NumericUpDown NUD2_11;
        private System.Windows.Forms.NumericUpDown NUD2_12;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.NumericUpDown NUD3_1;
        private System.Windows.Forms.NumericUpDown NUD3_2;
        private System.Windows.Forms.NumericUpDown NUD3_3;
        private System.Windows.Forms.NumericUpDown NUD3_4;
        private System.Windows.Forms.NumericUpDown NUD3_5;
        private System.Windows.Forms.NumericUpDown NUD3_6;
        private System.Windows.Forms.NumericUpDown NUD3_7;
        private System.Windows.Forms.NumericUpDown NUD3_8;
        private System.Windows.Forms.NumericUpDown NUD3_9;
        private System.Windows.Forms.NumericUpDown NUD3_10;
        private System.Windows.Forms.NumericUpDown NUD3_11;
        private System.Windows.Forms.NumericUpDown NUD3_12;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.NumericUpDown NUD4_1;
        private System.Windows.Forms.NumericUpDown NUD4_2;
        private System.Windows.Forms.NumericUpDown NUD4_3;
        private System.Windows.Forms.NumericUpDown NUD4_4;
        private System.Windows.Forms.NumericUpDown NUD4_5;
        private System.Windows.Forms.NumericUpDown NUD4_6;
        private System.Windows.Forms.NumericUpDown NUD4_7;
        private System.Windows.Forms.NumericUpDown NUD4_8;
        private System.Windows.Forms.NumericUpDown NUD4_9;
        private System.Windows.Forms.NumericUpDown NUD4_10;
        private System.Windows.Forms.NumericUpDown NUD4_11;
        private System.Windows.Forms.NumericUpDown NUD4_12;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.NumericUpDown NUD5_1;
        private System.Windows.Forms.NumericUpDown NUD5_2;
        private System.Windows.Forms.NumericUpDown NUD5_3;
        private System.Windows.Forms.NumericUpDown NUD5_4;
        private System.Windows.Forms.NumericUpDown NUD5_5;
        private System.Windows.Forms.NumericUpDown NUD5_6;
        private System.Windows.Forms.NumericUpDown NUD5_7;
        private System.Windows.Forms.NumericUpDown NUD5_8;
        private System.Windows.Forms.NumericUpDown NUD5_9;
        private System.Windows.Forms.NumericUpDown NUD5_10;
        private System.Windows.Forms.NumericUpDown NUD5_11;
        private System.Windows.Forms.NumericUpDown NUD5_12;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Button btnCCT;
        private System.Windows.Forms.TextBox txt_Ans1;
        private System.Windows.Forms.TextBox txt_Ans2;
        private System.Windows.Forms.TextBox txt_Ans3;
        private System.Windows.Forms.TextBox txt_Ans4;
        private System.Windows.Forms.TextBox txt_Ans5;
        private System.Windows.Forms.TextBox txt_Ans6;
        private System.Windows.Forms.TextBox txt_Ans7;
        private System.Windows.Forms.TextBox txt_Ans8;
        private System.Windows.Forms.TextBox txt_Ans9;
        private System.Windows.Forms.TextBox txt_Ans10;
        private System.Windows.Forms.TextBox txt_Ans11;
        private System.Windows.Forms.TextBox txt_Ans12;
        private System.Windows.Forms.Label lbl_Ans;
    }
}

