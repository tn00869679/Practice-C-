﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace BatteryID
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Console.WriteLine(string.Join(" , ", SerialPort.GetPortNames()));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived1);
            serialPort2.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived2);

            serialPort1.Open();
            serialPort2.Open();
            textBox1.KeyDown += new KeyEventHandler(textBox1_KeyDown);
            textBox2.KeyDown += new KeyEventHandler(textBox2_KeyDown);
            //serialPort1.Write("COM10-->COM11: Hello, what's your name?");
            //serialPort2.Write("COM11-->COM10: I am Zoper!");
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            serialPort1.Close();
            serialPort2.Close();
        }
        private void port_DataReceived1(object sender, SerialDataReceivedEventArgs e)
        {
            string response = serialPort1.ReadExisting();
            richTextBox1.Invoke(new EventHandler(delegate
            {
                richTextBox1.AppendText(response + "\n");
            }));
        }
        private void port_DataReceived2(object sender, SerialDataReceivedEventArgs e)
        {
            string response = serialPort2.ReadExisting();
            richTextBox2.Invoke(new EventHandler(delegate
            {
                richTextBox2.AppendText(response + "\n");
            }));
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                serialPort1.Write("COM10>> " + textBox1.Text);
                textBox1.Clear();
            }
        }
        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                serialPort2.Write("COM11>> " + textBox2.Text);
                textBox2.Clear();
            }
        }
    }
}
