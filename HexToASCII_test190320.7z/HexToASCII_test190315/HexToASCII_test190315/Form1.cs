﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HexToASCII_test190315
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void ASCII_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                byte[] ascii = System.Text.Encoding.Default.GetBytes(ASCII.Text);
                int count = ASCII.Text.Length;
                string[] HexTrans = new string[count];
                for (int size=0; size<count; size++)
                {
                    HexTrans[size] = ascii[size].ToString("x2");
                }
                Hex.Clear();
                Hex.Text = string.Join(" ",HexTrans);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                ASCII.Clear();
            }
        }

        private void Hex_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ASCII.Clear();
                ASCII.Text = HexStringToASCII(Hex.Text);

                //string[] hex = Hex.Text.Split(new Char[] { }, StringSplitOptions.RemoveEmptyEntries);
                //for(int size=0; size<hex.Length; size++)
                //{
                //    hex[size] = Convert.ToString(Convert.ToChar(Convert.ToInt32(string.Format("&h{0}", hex[size]))));
                //}
                //char ASCIITrans = Convert.ToChar(Hex.Text);
                //byte ascii = Convert.ToByte(ASCIITrans);
                //ASCII.Clear();
                //ASCII.Text = string.Join(string.Empty, hex);
            }
            else if (e.KeyCode == Keys.Escape)
            {
                Hex.Clear();
            }
        }

        public static byte[] HexStringToBinary(string hexstring)     //16進制轉2進制
        {
            try
            {
                string[] tmpary = hexstring.Trim().Split(' ');
                byte[] buff = new byte[tmpary.Length];
                for (int i = 0; i < buff.Length; i++)
                {
                    buff[i] = Convert.ToByte(tmpary[i], 16);
                }
                return buff;
            }
            catch (Exception ex)
            {
                byte[] error = new byte[5] { 69, 114, 114, 111, 114 };

                MessageBox.Show("數值間請加空白建區隔");
                return error;
            }
        }

        public static string HexStringToASCII(string hexstring)     //16進制轉ASCII
        {
            byte[] bt = HexStringToBinary(hexstring);
            string lin = "";
            for (int i = 0; i < bt.Length; i++)
            {
                lin = lin + bt[i] + " ";
            }


            string[] ss = lin.Trim().Split(new char[] { ' ' });
            char[] c = new char[ss.Length];
            int a;
            for (int i = 0; i < c.Length; i++)
            {
                a = Convert.ToInt32(ss[i]);
                c[i] = Convert.ToChar(a);
            }

            string b = new string(c);
            return b;
        }
    }
}
