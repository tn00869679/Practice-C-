﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace BatteryID
{
    public partial class Form1 : Form
    {
        string[] BatteryData = new string[] { "20180820", "80%", "50度C", "10A", "NO" };
        string BatteryDatatransfer;
        public Form1()
        {
            InitializeComponent();
            Console.WriteLine(string.Join(" , ", SerialPort.GetPortNames()));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BatteryDatatransfer = string.Concat("ID : " + BatteryData[0], "\nBattery : " + BatteryData[1], "\nTemp : " + BatteryData[2], "\nCurrent : " + BatteryData[3], "\nDocking : " + BatteryData[4],"\n");
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived1);
            serialPort2.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived2);
            serialPort1.Open();
            serialPort2.Open();
            textBox1.KeyDown += new KeyEventHandler(textBox1_KeyDown);
            richTextBox2.AppendText(BatteryDatatransfer);
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            serialPort1.Close();
            serialPort2.Close();
        }
        private void port_DataReceived1(object sender, SerialDataReceivedEventArgs e)
        {
            //List<string> response = new List<string>();
            string response = serialPort1.ReadExisting();
            //response.Add(serialPort1.ReadExisting());
            richTextBox1.Invoke(new EventHandler(delegate
            {
                richTextBox1.AppendText(response + "\n");
            }));
        }
        private void port_DataReceived2(object sender, SerialDataReceivedEventArgs e)
        {
            string response = serialPort2.ReadExisting();
            if (response == "1") serialPort2.Write(BatteryDatatransfer);
            //richTextBox2.Invoke(new EventHandler(delegate
            //{
            //    richTextBox2.AppendText(response + "\n");
            //}));
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if(textBox1.Text=="1")
                {
                    serialPort1.Write("1");
                    textBox1.Clear();
                }
                else
                {
                    textBox1.Clear();
                }
            }
        }
        //private void textBox2_KeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyCode == Keys.Enter)
        //    {
        //        serialPort2.Write("COM11>> " + textBox2.Text);
        //        textBox2.Clear();
        //    }
        //}
    }
}
