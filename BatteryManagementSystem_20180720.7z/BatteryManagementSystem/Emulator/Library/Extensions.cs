﻿using System;
using System.Windows.Threading;

namespace BatteryManagementSystem {
	/// <summary>控制項相關擴充方法</summary>
	internal static class UIExtensions {

		/// <summary>調用控制項以執行方法</summary>
		/// <param name="ctrl">欲調用之控制項</param>
		/// <param name="action">欲執行的方法</param>
		public static void TryInvoke(this DispatcherObject ctrl, Action action) {
			if (!ctrl.Dispatcher.CheckAccess()) {
				ctrl.Dispatcher.Invoke(action);
			} else action();
		}

		/// <summary>調用控制項以執行方法，使用非同步</summary>
		/// <param name="ctrl">欲調用之控制項</param>
		/// <param name="action">欲執行的方法</param>
		public static void TryBeginInvoke(this DispatcherObject ctrl, Action action) {
			if (!ctrl.Dispatcher.CheckAccess()) {
				ctrl.Dispatcher.BeginInvoke(action);
			} else action();
		}

		/// <summary>調用控制項以取得特定數值</summary>
		/// <param name="ctrl">欲調用之控制項</param>
		/// <param name="action">欲執行的方法</param>
		public static TObj TryInvoke<TObj>(this DispatcherObject ctrl, Func<TObj> action) {
			if (!ctrl.Dispatcher.CheckAccess()) {
				return (TObj) ctrl.Dispatcher.Invoke(action);
			} else return action();
		}
	}
}
