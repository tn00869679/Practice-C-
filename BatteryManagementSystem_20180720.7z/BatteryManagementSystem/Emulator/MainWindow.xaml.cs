﻿using CtLib.Module.BMS;
using MahApps.Metro.Controls;
using System;
using System.ComponentModel;
using System.Windows;

namespace BatteryManagementSystem {

	/// <summary>電池管理系統之互動邏輯</summary>
	public partial class MainWindow : MetroWindow, INotifyPropertyChanged {

		#region Fields
		/// <summary>目標 IP 位址</summary>
		private string mIP = string.Empty;
		/// <summary>目標埠號</summary>
		private int mPort = 502;
		/// <summary>操作電池管理系統之執行個體</summary>
		private CtBMS mBMS;
		/// <summary>基本資訊</summary>
		private BasicInformation mBasicInfo;
		/// <summary>系統資訊</summary>
		private SystemInformation mSysInfo;
		/// <summary>電池儲存元資訊</summary>
		private CellsInformation mCellInfo;
		#endregion

		#region Properties
		/// <summary>取得或設定目標 IP 位址</summary>
		public string IPAddress {
			get { return mIP; }
			set {
				mIP = value;
				Properties.Settings.Default.IP = value;
				Properties.Settings.Default.Save();
				RaisePropChg("IPAddress");
			}
		}
		/// <summary>取得或設定目標端點埠號</summary>
		public int Port {
			get { return mPort; }
			set {
				mPort = value;
				Properties.Settings.Default.Port = value;
				Properties.Settings.Default.Save();
				RaisePropChg("Port");
			}
		}
		/// <summary>取得當前是否已連線至目標端點</summary>
		public bool IsConnected => mBMS?.IsConnected ?? false;
		/// <summary>取得當前是否已進入唯讀狀態</summary>
		public bool IsReadOnly => !(mBMS?.IsConnected ?? false);
		/// <summary>取得繫結至 <see cref="ListBox"/> 的集合資料</summary>
		public BindingList<string> LogBinding { get; }
		/// <summary>取得或設定基本資訊</summary>
		public BasicInformation BasicInfo {
			get => mBasicInfo;
			set {
				mBasicInfo = value;
				RaisePropChg("BasicInfo");
			}
		}
		/// <summary>取得或設定系統資訊</summary>
		public SystemInformation SysInfo {
			get => mSysInfo;
			set {
				mSysInfo = value;
				RaisePropChg("SysInfo");
			}
		}
		/// <summary>取得或設定電池資訊</summary>
		public CellsInformation CellInfo {
			get => mCellInfo;
			set {
				mCellInfo = value;
				RaisePropChg("CellInfo");
			}
		}
		/// <summary>取得或設定欲查詢的電池編號</summary>
		public int BatteryIndex { get; set; } = 1;
		#endregion

		#region INotifyPropertyChanged Implements
		public event PropertyChangedEventHandler PropertyChanged;
		private void RaisePropChg(string name) {
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		}
		#endregion

		#region Constructors
		public MainWindow() {
			InitializeComponent();

			this.DataContext = this;
			mIP = Properties.Settings.Default.IP;
			mPort = Properties.Settings.Default.Port;

			LogBinding = new BindingList<string>();
			mBasicInfo = new BasicInformation();
			mSysInfo = new SystemInformation();
			mCellInfo = new CellsInformation();

			mBMS = new CtBMS();
			mBMS.ConnectionChanged += mBMS_ConnectionChanged;
		}
		#endregion

		#region CtBMS Event Handlers
		private void mBMS_ConnectionChanged(object sender, ConnectionEventArgs e) {
			RaisePropChg("IsConnected");
			RaisePropChg("IsReadOnly");
			if (e.State) {
				AddLog($"Connected to '{e.RemoteEndPoint.ToString()}'");
			} else {
				AddLog($"Disconnected from '{e.RemoteEndPoint.ToString()}'");
			}
		}
		#endregion

		#region Private Methods
		/// <summary>添加一筆記錄至 <see cref="ListBox"/> 與記錄檔</summary>
		/// <param name="data">紀錄內容</param>
		private void AddLog(string data) {
			var txt = string.Format(
				"[{0}] {1}",
				DateTime.Now.ToString("HH:mm:ss.fff"),
				data
			);
			lstLog.TryInvoke(() => LogBinding.Insert(0, txt));
		}
		#endregion

		#region UI Event Handlers
		private void ConnectClicked(object sender, RoutedEventArgs e) {
			if (mBMS.IsConnected) {
				mBMS.Disconnect();
			}

			try {
				/* 連線 */
				mBMS.Connect(mIP, mPort);
			} catch (Exception ex) {
				AddLog(ex.Message);
			}
		}

		private void DisconnectClicked(object sender, RoutedEventArgs e) {
			mBMS.Disconnect();
		}

		private void ClearLogClicked(object sender, RoutedEventArgs e) {
			lstLog.TryInvoke(() => LogBinding.Clear());
		}

		private void UpdateClicked(object sender, RoutedEventArgs e) {
			try {
				var basic = mBMS.GetBasic(BatteryIndex);
				var sys = mBMS.GetSystem(BatteryIndex);
				var cell = mBMS.GetCells(BatteryIndex);

				BasicInfo = basic;
				SysInfo = sys;
				CellInfo = cell;
			} catch (Exception ex) {
				AddLog(ex.Message);
			}
		}

		private void MetroWindow_Closing(object sender, CancelEventArgs e) {
			if (mBMS != null && mBMS.IsConnected) {
				mBMS.Disconnect();
			}
		}

		private void PowerOffClicked(object sender, RoutedEventArgs e) {
			mBMS.PowerOff();
		}
		#endregion
	}
}
