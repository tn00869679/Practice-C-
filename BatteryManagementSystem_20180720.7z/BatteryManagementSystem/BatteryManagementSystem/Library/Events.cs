﻿using System;
using System.Net;

namespace CtLib.Module.BMS {

	/// <summary>連線狀態改變事件參數</summary>
	public class ConnectionEventArgs : EventArgs {

		#region Properties
		/// <summary>取得連線狀態</summary>
		public bool State { get; }
		/// <summary>取得遠端端點資訊</summary>
		public EndPoint RemoteEndPoint { get; }
		/// <summary>取得發生改變的時間</summary>
		public DateTime Time { get; }
		#endregion

		#region Constructors
		/// <summary>建構連線狀態事件參數</summary>
		/// <param name="stt">連線狀態</param>
		/// <param name="ep">遠端端點資訊</param>
		/// <param name="time">發生改變的時間</param>
		public ConnectionEventArgs(bool stt, EndPoint ep, DateTime time) {
			State = stt;
			RemoteEndPoint = ep;
			Time = time;
		}
		#endregion
	}
}
