﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Net.Sockets;

namespace CtLib.Module.BMS {

	/// <summary>Battery Information</summary>
	public interface IBatteryInformation {

		/// <summary>Gets the battery number of BMS</summary>
		int BatteryNumber { get; }

	}

	/// <summary>Basic information of battery</summary>
	public sealed class BasicInformation : IBatteryInformation {

		#region Properties
		/// <summary>Gets the battery number of BMS</summary>
		public int BatteryNumber { get; }
		/// <summary>Gets estimated charge of the battery</summary>
		public float ChargeEstimate { get; }
		/// <summary>Gets current draw (or charge rate) from the battery</summary>
		public short CurrentDraw { get; }
		/// <summary>Gets voltage of the pack</summary>
		public short PackVoltage { get; }
		/// <summary>Gets info flags for the charge circuitry and system status</summary>
		public BatteryStatus Status { get; } = BatteryStatus.Unknown;
		/// <summary>Gets error information</summary>
		public BatteryError Error { get; } = BatteryError.NoError;
		#endregion

		#region Constructors
		public BasicInformation() {

		}

		internal BasicInformation(NetworkStream netStm) {
			BatteryNumber = (netStm.ReadByte() & 0xF0) >> 4;
			netStm.ReadByte(); //0x00
			netStm.ReadByte(); //長度
			ChargeEstimate = netStm.GetInt16() * 0.01F;
			CurrentDraw = netStm.GetInt16();
			PackVoltage = netStm.GetInt16();
			Status = (BatteryStatus) netStm.GetUInt16();
			Error = (BatteryError) netStm.GetUInt16();
		}
		#endregion
	}

	/// <summary>System information of battery</summary>
	public sealed class SystemInformation : IBatteryInformation {

		#region Properties
		/// <summary>Gets the battery number of BMS</summary>
		public int BatteryNumber { get; }
		/// <summary>Gets battery Pack Type</summary>
		public BatteryType Type { get; } = BatteryType.MTX_8Cells;
		/// <summary>Gets firmware version</summary>
		public byte FirmwareVersion { get; }
		/// <summary>Gets serial number</summary>
		public uint SerialNumber { get; }
		/// <summary>Gets timestamp from the battery Real Time Clock</summary>
		public long Time { get; }
		/// <summary>Gets time battery was last charging</summary>
		public long LastChargeTime { get; }
		/// <summary>Gets estimated total charge remaining in battery in Coulombs (Amp-seconds)</summary>
		public uint ChargeEstimate { get; }
		/// <summary>Gets estimated maximum battery capacity in Coulombs (Amp-seconds)</summary>
		public uint CapacityEstimate { get; }
		/// <summary>Gets power off delay time for a non-emergency power off request</summary>
		public uint Delay { get; }
		/// <summary>Gets number of charge/discharge cycles for this battery</summary>
		public ushort CycleCount { get; }
		/// <summary>Gets temperature of the battery board</summary>
		public float Temperature { get; }
		/// <summary>Gets voltage on the charge paddles</summary>
		public ushort VCHARGE_IN { get; }
		/// <summary>Gets battery voltage</summary>
		public ushort VBAT_OUT { get; }
		/// <summary>Gets fuse voltage. If not approx. equal to VBAT_OUT then a fuse is blown</summary>
		public ushort VBAT_F50 { get; }
		/// <summary>Gets incoming current from the charger</summary>
		public ushort ChargeCurrent { get; }
		/// <summary>Gets outgoing current from the battery</summary>
		public ushort DischargeCurrent { get; }
		/// <summary>Gets maximum cell imbalabce, as a percent of capacity</summary>
		public float CellImbalance { get; }
		/// <summary>Gets required cell imbalance for complete charge</summary>
		public float ImbalanceQuality { get; }
		/// <summary>Gets reserve charge value</summary>
		public float Reserve { get; }
		#endregion

		#region Constructors
		public SystemInformation() {

		}

		internal SystemInformation(NetworkStream netStm) {
			BatteryNumber = (netStm.ReadByte() & 0xF0) >> 4;
			netStm.ReadByte(); //0x00
			netStm.ReadByte(); //長度
			Type = (BatteryType) netStm.ReadByte();
			FirmwareVersion = (byte) netStm.ReadByte();
			SerialNumber = netStm.GetUInt32();
			Time = netStm.GetInt64();
			LastChargeTime = netStm.GetInt64();
			ChargeEstimate = netStm.GetUInt32();
			CapacityEstimate = netStm.GetUInt32();
			Delay = netStm.GetUInt32();
			CycleCount = netStm.GetUInt16();
			Temperature = netStm.GetInt16() * 0.01F;
			VCHARGE_IN = netStm.GetUInt16();
			VBAT_OUT = netStm.GetUInt16();
			VBAT_F50 = netStm.GetUInt16();
			ChargeCurrent = netStm.GetUInt16();
			DischargeCurrent = netStm.GetUInt16();
			CellImbalance = netStm.GetUInt16() * 0.01F;
			ImbalanceQuality = netStm.GetUInt16() * 0.01F;
			Reserve = netStm.GetUInt16() * 0.01F;
		}
		#endregion
	}

	/// <summary>Cell Packet Information</summary>
	public sealed class CellsInformation : IBatteryInformation {

		#region Fields
		private readonly List<Cell> mCells;
		#endregion

		#region Properties
		/// <summary>Gets the battery number of BMS</summary>
		public int BatteryNumber { get; }
		/// <summary>Gets number of cells in the bettery pack</summary>
		public int CellsCount { get; }
		/// <summary>Gets detail information of cell</summary>
		public ReadOnlyCollection<Cell> Cells => new ReadOnlyCollection<Cell>(mCells);
		#endregion

		#region Constructors
		public CellsInformation() {
			mCells = new List<Cell> {
				new Cell(0), new Cell(1), new Cell(2), new Cell(3),
				new Cell(4), new Cell(5), new Cell(6), new Cell(7)
			};
		}

		internal CellsInformation(NetworkStream netStm) {
			mCells = new List<Cell>();
			BatteryNumber = (netStm.ReadByte() & 0xF0) >> 4;
			netStm.ReadByte(); //0x00
			netStm.ReadByte(); //長度
			CellsCount = netStm.ReadByte();
			for (int i = 0; i < 8; i++) {
				var cell = new Cell(i, netStm);
				mCells.Add(cell);
			}
		}
		#endregion
	}

	/// <summary>Cell Information</summary>
	public sealed class Cell {

		#region Properties
		/// <summary>Gets the index of cell pack</summary>
		public int CellNumber { get; }
		/// <summary>Gets status flags for the cell</summary>
		public CellStatus Status { get; } = CellStatus.BalancerOn;
		/// <summary>Gets voltage of cell</summary>
		public ushort Voltage { get; }
		/// <summary>Gets estimate of charge remaining in cell</summary>
		public uint Charge { get; }
		/// <summary>Gets estimate of maximum capacity of cell</summary>
		public uint Capacity { get; }
		#endregion

		#region Constructors
		internal Cell(int idx) {
			CellNumber = idx;
		}

		internal Cell(int idx, NetworkStream netStm) {
			CellNumber = idx;
			Status = (CellStatus) netStm.ReadByte();
			Voltage = netStm.GetUInt16();
			Charge = netStm.GetUInt32();
			Capacity = netStm.GetUInt32();
		}
		#endregion
	}

	/// <summary>Battery Status</summary>
	public enum BatteryStatus : ushort {
		Unknown = 0x0000,
		OnCharger = 0x0001,
		Charging = 0x0002,
		ChargeBalancing = 0x0004,
		ChargerOn = 0x0008,
		PowerOffCountDown = 0x0010,
		MasterSwitchOn = 0x0020,
		ChargeSwitchOn = 0x0040,
		CommandedShutdown = 0x0080,
		OffButtonPressed = 0x0100,
		OnButtonPressed = 0x0200,
		UserButtonPressed = 0x0400
	}

	/// <summary>Battery Error</summary>
	public enum BatteryError : ushort {
		NoError = 0x0000,
		OverVoltage = 0x0001,
		UnderVoltage = 0x0002,
		OverCurrent = 0x0004,
		BlowFuse = 0x0008,
		RtcError = 0x0010,
		OverTemperature = 0x0020,
		MasterSwitchFault = 0x0040,
		SramError = 0x0080,
		ChargerOutOfVoltageRange = 0x0100,
		ChargeCircuitFault = 0x0200,
		ChargerOverCurrent = 0x0400
	}

	/// <summary>Battery Type</summary>
	public enum BatteryType : byte {
		Unknown = 0x00,
		MTX_8Cells = 0x01
	}

	/// <summary>Status flag for the cell</summary>
	public enum CellStatus : byte {
		BalancerOn = 0x01,
		OverVoltage = 0x02,
		UnderVoltage = 0x04
	}
}
