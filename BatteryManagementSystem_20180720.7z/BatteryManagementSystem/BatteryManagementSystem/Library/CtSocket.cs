﻿using System;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;

namespace CtLib.Module.Net {

	/// <summary>實作 Berkeley 通訊端介面，使用 TCP</summary>
	/// <remarks>
	/// 因考量到 I/O 會一直 polling，且通訊協定為一問一答
	/// 故這邊不採用事件方式發報資料，並直接採同步操作，簡化流程，避免亂亂來
	/// </remarks>
	internal class CtSocket : IDisposable {

		#region Definitions
		/// <summary>接收資料的預設緩衝區大小</summary>
		public static readonly int BUFFER_SIZE = 1024;
		#endregion

		#region Fields
		/// <summary>
		/// 暫存 Socket 連線物件
		/// <para>[Client] 與 Server 連線之 Socket</para>
		/// <para>[Server] 接收 Client 連線之 Listen Socket</para>
		/// </summary>
		private Socket mSocket;
		/// <summary>
		/// [Client] 目標伺服器之 IP Address
		/// <para>[Server] 本機伺服器</para>
		/// </summary>
		private IPAddress mIP;
		/// <summary>
		/// [Client] 目標伺服器之網路埠號
		/// <para>[Server] 本機監聽埠號</para>
		/// </summary>
		private int mPort = 0;
		#endregion

		#region Properties
		/// <summary>
		/// [Client] 取得當前與 Server 連線狀態
		/// <para>[Server] 當前是否有任一 Client 連線至 Server</para>
		/// </summary>
		internal bool IsConnected => mSocket?.IsConnected() ?? false;
		#endregion

		#region Events
		/// <summary>連線狀態變更</summary>
		/// <param name="stt">當前狀態</param>
		/// <param name="endPoint">遠端端點資訊  [Client]目標伺服器位址 [Server]已連入的用戶端位址</param>
		/// <param name="time">發生改變之時間</param>
		internal delegate void ConnectState(bool stt, EndPoint endPoint, DateTime time);

		/// <summary>連線狀態發生變化</summary>
		internal event ConnectState ConnectionChanged;

		/// <summary>發布連線狀態變更，採用非同步方式發送</summary>
		/// <param name="stt">當前狀態</param>
		/// <param name="endPoint">遠端端點資訊  [Client]目標伺服器位址 [Server]已連入的用戶端位址</param>
		/// <param name="time">發生改變之時間</param>
		protected virtual void RaiseConnStt(bool stt, EndPoint endPoint, DateTime time) {
			ConnectionChanged?.BeginInvoke(stt, endPoint, time, null, null);
		}
		#endregion

		#region Constructors
		/// <summary>建構通訊物件</summary>
		internal CtSocket() {

		}
		#endregion

		#region Client
		/// <summary>連線至目標端點</summary>
		/// <param name="ip">目標網際網路位址</param>
		/// <param name="port">目標埠號</param>
		/// <param name="sendTimeout">等待傳送的逾時時間，單位為毫秒</param>
		/// <param name="receiveTimeout">等待接收的逾時時間，單位為毫秒</param>
		internal void ClientConnect(string ip, int port, int sendTimeout, int receiveTimeout) {
			if (!Equals(mSocket, null) && mSocket.IsConnected())
				throw new InvalidOperationException("Please disconnect before connecting");

			/* 檢查目標裝置在不在 */
			var ping = new Ping();
			var result = ping.Send(ip, 500);
			if (result.Status != IPStatus.Success) {
				throw new InvalidOperationException($"Target server '{ip}' was not alive");
			}

			/* 紀錄連線資訊 */
			mIP = IPAddress.Parse(ip);
			mPort = port;
			/* 建立 Socket */
			var endPoint = new IPEndPoint(mIP, mPort);
			mSocket = new Socket(
				AddressFamily.InterNetwork,
				SocketType.Stream,
				ProtocolType.Tcp
			) {
				NoDelay = true,
				ReceiveTimeout = receiveTimeout,    //等待逾時，超過 Read 會跳 Exception
				SendTimeout = sendTimeout           //傳送逾時，超過 send 會跳 Exception
			};
			/* 連線 */
			mSocket.Connect(endPoint);
			/* 發布事件 */
			RaiseConnStt(true, endPoint, DateTime.Now);
		}

		/// <summary>中斷與伺服端之連線</summary>
		internal void ClientDisconnect() {
			if (!Equals(mSocket, null)) {
				/* 紀錄時間 */
				var time = DateTime.Now;
				/* 先關 Stream */
				try {
					mSocket?.Shutdown(SocketShutdown.Both);
				} catch (Exception ex) {
					/* 因是要斷線的 Exception，無關緊要，故不用寫 Logger*/
					Console.WriteLine(ex.Message);
				}
				/* 再關 Socket */
				mSocket?.Close();
				mSocket = null; //避免下次 Connect 時判斷錯誤
								/* 發布事件 */
				RaiseConnStt(false, new IPEndPoint(mIP, mPort), time);
			}
		}
		#endregion

		#region Receive
		/// <summary>從串流中收取資料</summary>
		/// <param name="buffer">欲存放資料之緩衝區</param>
		/// <returns>接收到的 byte 數量</returns>
		public int Receive(byte[] buffer) {
			return mSocket.Receive(buffer);
		}

		/// <summary>使用自訂的方法從串流中收取資料</summary>
		/// <param name="action">自訂方法</param>
		/// <returns>接收到的 byte 數量</returns>
		public int Receive(Func<NetworkStream, int> action) {
			try {
				using (var netStream = new NetworkStream(mSocket)) {
					return action(netStream);
				}
			} catch (Exception ex) {
				Console.WriteLine(ex.Message);
				return 0;
			}
		}

		public T Receive<T>(Func<NetworkStream, T> action) {
			try {
				using (var netStream = new NetworkStream(mSocket)) {
					return action(netStream);
				}
			} catch (Exception ex) {
				Console.WriteLine(ex.Message);
				return default(T);
			}
		}
		#endregion

		#region Send
		/// <summary>傳送資料至目標端點</summary>
		/// <param name="data">欲傳送之資料</param>
		/// <returns>是否傳送成功</returns>
		public bool Send(byte[] data) {
			return mSocket.Send(data) == data.Length;
		}

		/// <summary>傳送資料至目標端點</summary>
		/// <param name="data">欲傳送之資料</param>
		/// <param name="count">欲傳送多少筆資料</param>
		/// <returns>是否傳送成功</returns>
		public bool Send(byte[] data, int count) {
			try {
				return mSocket.Send(data, count, SocketFlags.None) == count;
			} catch (Exception ex) {
				Console.WriteLine(ex.Message);
				return false;
			}
		}
		#endregion

		#region IDisposable Support
		private bool disposedValue = false; // 偵測多餘的呼叫

		protected virtual void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: 處置受控狀態 (受控物件)。
					ClientDisconnect();
				}

				// TODO: 釋放非受控資源 (非受控物件) 並覆寫下方的完成項。
				// TODO: 將大型欄位設為 null。

				disposedValue = true;
			}
		}

		// TODO: 僅當上方的 Dispose(bool disposing) 具有會釋放非受控資源的程式碼時，才覆寫完成項。
		// ~CtSocket() {
		//   // 請勿變更這個程式碼。請將清除程式碼放入上方的 Dispose(bool disposing) 中。
		//   Dispose(false);
		// }

		// 加入這個程式碼的目的在正確實作可處置的模式。
		public void Dispose() {
			// 請勿變更這個程式碼。請將清除程式碼放入上方的 Dispose(bool disposing) 中。
			Dispose(true);
			// TODO: 如果上方的完成項已被覆寫，即取消下行的註解狀態。
			// GC.SuppressFinalize(this);
		}
		#endregion
	}
}
