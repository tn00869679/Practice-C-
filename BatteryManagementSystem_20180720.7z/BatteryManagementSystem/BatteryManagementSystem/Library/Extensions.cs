﻿using System;
using System.IO;
using System.Net.Sockets;

namespace CtLib.Module.Net {

	/// <summary>網路相關物件之擴充方法</summary>
	internal static class NetExtension {

		/// <summary>取得此 <see cref="Socket"/> 是否有成功連線至端點。採用 <see cref="Socket.Poll(int, SelectMode)"/> 進行檢查</summary>
		/// <param name="socket">欲檢查的 <see cref="Socket"/> 物件</param>
		/// <returns>(True)連線至端點  (False)未連線</returns>
		internal static bool IsConnected(this Socket socket) {
			return socket.Connected && !(socket.Poll(1000, SelectMode.SelectRead) && (socket.Available == 0));
		}

		/// <summary>將陣列轉換為 ArraySegment</summary>
		/// <param name="buffer">欲轉換之陣列</param>
		/// <returns>ArraySegment</returns>
		internal static ArraySegment<T> ToSegment<T>(this T[] buffer) where T : struct {
			return new ArraySegment<T>(buffer);
		}
	}
}

namespace CtLib.Module.BMS {

	/// <summary>數值轉換之擴充方法</summary>
	internal static class ConvertExtension {

		/// <summary>從串流中讀取 2 bytes 並轉換為 <see cref="short"/></summary>
		/// <param name="memStem">欲讀取的串流</param>
		/// <returns>轉換後的數值</returns>
		/// <remarks>目前僅寫 LittleEndian，若為 BigEndian 請再進行修改</remarks>
		internal static short GetInt16(this Stream memStem) {
			var buf = new byte[2];
			memStem.Read(buf, 0, 2);
			return (short) ((buf[1] << 8) | buf[0]);
		}

		/// <summary>從串流中讀取 4 bytes 並轉換為 <see cref="int"/></summary>
		/// <param name="memStem">欲讀取的串流</param>
		/// <returns>轉換後的數值</returns>
		/// <remarks>目前僅寫 LittleEndian，若為 BigEndian 請再進行修改</remarks>
		internal static int GetInt32(this Stream memStem) {
			var buf = new byte[4];
			memStem.Read(buf, 0, 4);
			return BitConverter.ToInt32(buf, 0);
		}

		/// <summary>從串流中讀取 8 bytes 並轉換為 <see cref="long"/></summary>
		/// <param name="memStem">欲讀取的串流</param>
		/// <returns>轉換後的數值</returns>
		/// <remarks>目前僅寫 LittleEndian，若為 BigEndian 請再進行修改</remarks>
		internal static long GetInt64(this Stream memStem) {
			var buf = new byte[8];
			memStem.Read(buf, 0, 8);
			return BitConverter.ToInt64(buf, 0);
		}

		/// <summary>從串流中讀取 2 bytes 並轉換為 <see cref="ushort"/></summary>
		/// <param name="memStem">欲讀取的串流</param>
		/// <returns>轉換後的數值</returns>
		/// <remarks>目前僅寫 LittleEndian，若為 BigEndian 請再進行修改</remarks>
		internal static ushort GetUInt16(this Stream memStem) {
			var buf = new byte[2];
			memStem.Read(buf, 0, 2);
			return (ushort) ((buf[1] << 8) | buf[0]);
		}

		/// <summary>從串流中讀取 4 bytes 並轉換為 <see cref="uint"/></summary>
		/// <param name="memStem">欲讀取的串流</param>
		/// <returns>轉換後的數值</returns>
		/// <remarks>目前僅寫 LittleEndian，若為 BigEndian 請再進行修改</remarks>
		internal static uint GetUInt32(this Stream memStem) {
			var buf = new byte[4];
			memStem.Read(buf, 0, 4);
			return BitConverter.ToUInt32(buf, 0);
		}

		/// <summary>從串流中讀取 8 bytes 並轉換為 <see cref="ulong"/></summary>
		/// <param name="memStem">欲讀取的串流</param>
		/// <returns>轉換後的數值</returns>
		/// <remarks>目前僅寫 LittleEndian，若為 BigEndian 請再進行修改</remarks>
		internal static ulong GetUInt64(this Stream memStem) {
			var buf = new byte[8];
			memStem.Read(buf, 0, 8);
			return BitConverter.ToUInt64(buf, 0);
		}

	}

}