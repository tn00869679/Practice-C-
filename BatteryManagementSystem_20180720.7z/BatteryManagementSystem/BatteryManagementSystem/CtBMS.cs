﻿using CtLib.Module.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;

namespace CtLib.Module.BMS {

	public sealed class CtBMS : IDisposable {

		#region Definitions
		/// <summary>等待回應的逾時時間，單位為毫秒</summary>
		private static readonly int ResponseTimeout = 3000;
		/// <summary>取得一號電池基本資訊之命令</summary>
		private static readonly byte BasicInfo = 0x00;
		/// <summary>取得一號電池系統資訊之命令</summary>
		private static readonly byte SystemInfo = 0x01;
		/// <summary>取得一號電池電池元件資訊之命令</summary>
		private static readonly byte CellsInfo = 0x02;
		/// <summary>要求準備關閉電源之命令</summary>
		private static readonly byte[] PresetPowerOff = new byte[] { 0xFC };
		/// <summary>關閉電源之命令</summary>
		private static readonly byte[] SetPowerOff = new byte[] { 0xFE };
		#endregion

		#region Fields
		/// <summary>目標 IP 位址</summary>
		private IPAddress mIP;
		/// <summary>目標埠號</summary>
		private int mPort = 502;
		/// <summary>操作 TCP/IP 之物件</summary>
		private CtSocket mSocket;
		/// <summary>回應之命令</summary>
		private byte[] mEcho = new byte[] { 0x30, 0x00, 0x00, 0x00 };
		/// <summary>接收資料用的緩衝區</summary>
		private readonly byte[] mRxBuf = new byte[1024];
		/// <summary>緩衝區內有多少筆實際資料</summary>
		private int mRxCnt = 0;
		#endregion

		#region Properties
		/// <summary>取得當前是否已連線至目標端點</summary>
		public bool IsConnected => mSocket?.IsConnected ?? false;
		#endregion

		#region Events
		/// <summary>連線狀態變更事件</summary>
		public event EventHandler<ConnectionEventArgs> ConnectionChanged;
		#endregion

		#region Constructors
		public CtBMS() {
			/* 初始化物件 */
			mSocket = new CtSocket();
			mSocket.ConnectionChanged += mSocket_ConnectionChanged;
		}
		#endregion

		#region CtSocket Events
		/// <summary>TCP/IP 連線狀態改變</summary>
		/// <param name="stt">(True)已連線  (False)斷線</param>
		/// <param name="endPoint">發生改變的目標端點資訊</param>
		/// <param name="time">發生改變的時間</param>
		private void mSocket_ConnectionChanged(bool stt, EndPoint endPoint, DateTime time) {
			//因 CtSocket 是非同步發出來的，所以這邊走同步即可
			ConnectionChanged?.Invoke(this, new ConnectionEventArgs(stt, endPoint, time));
		}
		#endregion

		#region Connections
		/// <summary>嘗試連線至 Ethernet I/O</summary>
		/// <param name="ip">端點網際網路位址</param>
		/// <param name="port">端點埠號</param>
		public void Connect(string ip, int port) {
			/* 紀錄資訊 */
			mIP = IPAddress.Parse(ip);
			mPort = port;
			/* 連線，成功會由事件通知 */
			mSocket.ClientConnect(ip, port, ResponseTimeout, ResponseTimeout);
		}

		/// <summary>中斷與 Ethernet I/O 的連線</summary>
		public void Disconnect() {
			mSocket?.ClientDisconnect();
		}
		#endregion

		#region Private Methods
		/// <summary>傳送命令並於收到回覆後將資料存放至 <see cref="mRxBuf"/> 中</summary>
		/// <param name="data">欲傳送的命令</param>
		private void SendAndReply(byte[] data) {
			if (mSocket.Send(data)) {
				mRxCnt = mSocket.Receive(mRxBuf);
			}
		}

		/// <summary>傳送命令並於收到回覆後進行解碼</summary>
		/// <typeparam name="T">電池資訊</typeparam>
		/// <param name="data">欲傳送的命令</param>
		/// <returns>解碼後的電池資訊</returns>
		private T SendAndDecode<T>(byte[] data) where T : IBatteryInformation {
			if (!mSocket.IsConnected) {
				throw new InvalidOperationException("Invalid connection state");
			}

			var info = default(T);
			if (mSocket.Send(data)) {
				info = mSocket.Receive(
					netStm => {
						var obj = Activator.CreateInstance(
							typeof(T),
							(BindingFlags.Instance | BindingFlags.NonPublic),
							null,
							new object[] { netStm },
							null
						);
						return (T) obj;
					}
				);
			}
			return info;
		}
		#endregion

		#region Public Operations
		/// <summary>取得電池的基本資訊</summary>
		/// <param name="no">欲取得的電池編號</param>
		/// <returns>基本資訊</returns>
		public BasicInformation GetBasic(int no) {
			var cmd = new byte[] { (byte) ((no << 4) | BasicInfo) };
			return SendAndDecode<BasicInformation>(cmd);
		}

		/// <summary>取得電池的系統資訊</summary>
		/// <param name="no">欲取得的電池編號</param>
		/// <returns>系統資訊</returns>
		public SystemInformation GetSystem(int no) {
			var cmd = new byte[] { (byte) ((no << 4) | SystemInfo) };
			return SendAndDecode<SystemInformation>(cmd);
		}

		/// <summary>取得電池儲存元資訊</summary>
		/// <param name="no">欲取得的電池編號</param>
		/// <returns>儲存元資訊</returns>
		public CellsInformation GetCells(int no) {
			var cmd = new byte[] { (byte) ((no << 4) | CellsInfo) };
			return SendAndDecode<CellsInformation>(cmd);
		}

		/// <summary>要求電池板進行重複回應</summary>
		/// <param name="data">欲傳送的訊息</param>
		/// <returns>(True)回應相同訊息  (False)回應不同</returns>
		public bool Echo(byte[] data) {
			if (data.Length > 3) {
				throw new ArgumentOutOfRangeException("data", "Only can echo 3 bytes");
			}

			for (int idx = 0; idx < data.Length; idx++) {
				mEcho[idx + 1] = data[idx];
			}

			SendAndReply(mEcho);

			var compare = mRxCnt.Equals(mEcho.Length);
			if (compare) {
				for (int idx = 0; idx < mEcho.Length; idx++) {
					if (mRxBuf[idx] != mEcho[idx]) {
						compare = false;
						break;
					}
				}
			}
			return compare;
		}

		public void PowerOff() {
			SendAndReply(PresetPowerOff);
			if (mRxCnt <= 0 || mRxBuf[0] != PresetPowerOff[0]) {
				throw new Exception("Connection broken");
			}

			SendAndReply(SetPowerOff);
			if (mRxCnt <= 0 || mRxBuf[0] != SetPowerOff[0]) {
				throw new Exception("Connection broken");
			}
		}
		#endregion

		#region IDisposable Support
		private bool disposedValue = false; // 偵測多餘的呼叫

		void Dispose(bool disposing) {
			if (!disposedValue) {
				if (disposing) {
					// TODO: 處置受控狀態 (受控物件)。
					if (mSocket != null) {
						mSocket.Dispose();
					}
				}

				// TODO: 釋放非受控資源 (非受控物件) 並覆寫下方的完成項。
				// TODO: 將大型欄位設為 null。
				mSocket = null;
				disposedValue = true;
			}
		}

		// TODO: 僅當上方的 Dispose(bool disposing) 具有會釋放非受控資源的程式碼時，才覆寫完成項。
		// ~CtBMS() {
		//   // 請勿變更這個程式碼。請將清除程式碼放入上方的 Dispose(bool disposing) 中。
		//   Dispose(false);
		// }

		// 加入這個程式碼的目的在正確實作可處置的模式。
		public void Dispose() {
			// 請勿變更這個程式碼。請將清除程式碼放入上方的 Dispose(bool disposing) 中。
			Dispose(true);
			// TODO: 如果上方的完成項已被覆寫，即取消下行的註解狀態。
			// GC.SuppressFinalize(this);
		}
		#endregion
	}
}
