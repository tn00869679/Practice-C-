﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;
using System.Threading;

namespace BatteryCommunication
{
    public partial class Form1 : Form
    {
        List<byte> CommandList = new List<byte>();
        Thread ThdLockPage;
        Thread ThdUpdatePeriod;
        public Form1()
        {
            InitializeComponent();

            ThdLockPage = new Thread(tabPageLocking);
            ThdUpdatePeriod = new Thread(BatUpdatePeriod);
            ThdLockPage.IsBackground = true;
            ThdUpdatePeriod.IsBackground = true;

            button1.BackColor = Color.GreenYellow;
            TBCButton.BackColor = Color.GreenYellow;
            TBCUpdatePeriod.BackColor = Color.GreenYellow;
            
            string[] PortNames = SerialPort.GetPortNames();
            COMPort.Items.AddRange(PortNames);
            TBCCOMPort.Items.AddRange(PortNames);
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(PortReply);
            textBox2.KeyDown += new KeyEventHandler(textBox2_keyDown);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == 0)
            {
                textBox2.Visible = false;
                CommandCombine(0);
            }
            else if(comboBox1.SelectedIndex == 1)
            {
                textBox2.Visible = false;
                CommandCombine(1);
            }
            else if(comboBox1.SelectedIndex == 2)
            {
                textBox2.Visible = true;
            }
            else if(comboBox1.SelectedIndex == 3)
            {
                textBox2.Visible = false;
                CommandCombine(3);
            }
            else if(comboBox1.SelectedIndex == 4)
            {
                textBox2.Visible = true;
            }
            else
            {
                textBox2.Visible = false;
                textBox1.Clear();
            }
        }
        bool IDorSN = false;
        bool IsBAT = false;
        bool UpdatePeriod = false;
        private void PortReply(object sender,SerialDataReceivedEventArgs e)     //SerialPort讀取到的資料處理
        {
            byte[] PortData = new byte[1024];
            Thread.Sleep(50);
            int size = serialPort1.Read(PortData, 0, 1024);
            textBox1.Invoke(new EventHandler(delegate
            {
                textBox1.Clear();
                textBox1.AppendText(BitConverter.ToString(PortData, 0, size).Replace('-', ' '));
            }));
            if(IDorSN == false & IsBAT == false)
            {
                TBCID.Invoke(new EventHandler(delegate
                {
                    TBCID.Clear();
                    TBCID.AppendText(BitConverter.ToString(PortData, 0, size).Replace('-', ' '));
                }));
                TBCIDTrans.Invoke(new EventHandler(delegate
                {
                    TBCIDTrans.Clear();
                    TBCIDTrans.AppendText(BitConverter.ToString(PortData, 4, 1).Replace('-', ' '));
                }));
            }
            else if(IsBAT == true)
            {
                //if (UpdatePeriod == true)
                //{
                //    //while(TBCUpdatePeriod.BackColor == Color.Pink)
                //    {
                //        TBCCE.Invoke(new EventHandler(delegate
                //        {
                //            TBCCE.Clear();
                //            string BATCE = (BitConverter.ToString(PortData, 5, 1) + BitConverter.ToString(PortData, 4, 1));
                //            double BATCETrans = (Convert.ToDouble(HexToDec(BATCE))) * 0.01;
                //            TBCCE.AppendText(Convert.ToString(BATCETrans));
                //        }));
                //        TBCCD.Invoke(new EventHandler(delegate
                //        {
                //            TBCCD.Clear();
                //            string BATCD = (BitConverter.ToString(PortData, 7, 1) + BitConverter.ToString(PortData, 6, 1));
                //            double BATCDTrans = (Convert.ToDouble(HexToDec(BATCD))) * 0.01;
                //            TBCCD.AppendText(Convert.ToString(BATCDTrans));
                //        }));
                //        TBCPV.Invoke(new EventHandler(delegate
                //        {
                //            TBCPV.Clear();
                //            string BATPV = (BitConverter.ToString(PortData, 9, 1) + BitConverter.ToString(PortData, 8, 1));
                //            double BATPVTrans = (Convert.ToDouble(HexToDec(BATPV))) * 0.001;
                //            TBCPV.AppendText(Convert.ToString(BATPVTrans));
                //        }));
                //        TBCSF.Invoke(new EventHandler(delegate
                //        {
                //            TBCSF.Clear();
                //            string BATSF = (BitConverter.ToString(PortData, 11, 1) + BitConverter.ToString(PortData, 10, 1));
                //            TBCSF.AppendText(BATSF);
                //        }));
                //        TBCEF.Invoke(new EventHandler(delegate
                //        {
                //            TBCEF.Clear();
                //            string BATEF = (BitConverter.ToString(PortData, 13, 1) + BitConverter.ToString(PortData, 12, 1));
                //            TBCEF.AppendText(BATEF);
                //        }));
                //        //Thread.Sleep(1000);
                //    }
                //    UpdatePeriod = false;
                //}
                //else
                //{
                    TBCCE.Invoke(new EventHandler(delegate
                    {
                        TBCCE.Clear();
                        string BATCE = (BitConverter.ToString(PortData, 5, 1) + BitConverter.ToString(PortData, 4, 1));
                        double BATCETrans = (Convert.ToDouble(HexToDec(BATCE))) * 0.01;
                        TBCCE.AppendText(Convert.ToString(BATCETrans));
                    }));
                    TBCCD.Invoke(new EventHandler(delegate
                    {
                        TBCCD.Clear();
                        string BATCD = (BitConverter.ToString(PortData, 7, 1) + BitConverter.ToString(PortData, 6, 1));
                        double BATCDTrans = (Convert.ToDouble(HexToDec(BATCD))) * 0.01;
                        TBCCD.AppendText(Convert.ToString(BATCDTrans));
                    }));
                    TBCPV.Invoke(new EventHandler(delegate
                    {
                        TBCPV.Clear();
                        string BATPV = (BitConverter.ToString(PortData, 9, 1) + BitConverter.ToString(PortData, 8, 1));
                        double BATPVTrans = (Convert.ToDouble(HexToDec(BATPV))) * 0.001;
                        TBCPV.AppendText(Convert.ToString(BATPVTrans));
                    }));
                    TBCSF.Invoke(new EventHandler(delegate
                    {
                        TBCSF.Clear();
                        string BATSF = (BitConverter.ToString(PortData, 11, 1) + BitConverter.ToString(PortData, 10, 1));
                        TBCSF.AppendText(BATSF);
                    }));
                    TBCEF.Invoke(new EventHandler(delegate
                    {
                        TBCEF.Clear();
                        string BATEF = (BitConverter.ToString(PortData, 13, 1) + BitConverter.ToString(PortData, 12, 1));
                        TBCEF.AppendText(BATEF);
                    }));
                //}
                IsBAT = false;
            }
            else
            {
                TBCSN.Invoke(new EventHandler(delegate
                {
                    TBCSN.Clear();
                    TBCSN.AppendText(BitConverter.ToString(PortData, 0, size).Replace('-', ' '));
                }));
                TBCSNTrans.Invoke(new EventHandler(delegate
                {
                    TBCSNTrans.Clear();
                    TBCSNTrans.AppendText(BitConverter.ToString(PortData, 4, 4).Replace('-', ' '));
                }));
                IDorSN = false;
            }
            
        }
        private void textBox2_keyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                if(comboBox1.SelectedIndex == 2)
                {
                    CommandCombine(2);
                }
                else
                {
                    CommandCombine(4);
                }
                textBox2.Clear();
            }
        }

        private void COMPort_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.PortName = (string)COMPort.SelectedItem;
        }

        private void BaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.BaudRate = Convert.ToInt32(BaudRate.SelectedItem);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Connected)
            {
                serialPort1.Close();
                button1.Text = "Connect";
                button1.BackColor = Color.GreenYellow;
            }
            else
            {
                try
                {
                    if (COMPort.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else if (BaudRate.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else
                    {
                        serialPort1.Open();
                        button1.Text = "Disconnect";
                        button1.BackColor = Color.Pink;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Connecting failed");
                }
            }
        }
        private void SendCommand(byte[] Cmd)     //傳送指令
        {
            if(Connected != false)
            {
                serialPort1.Write(Cmd,0,Cmd.Length);
            }
            else
            {
                MessageBox.Show("Not Connected!!!");
            }
        }
        public bool Connected     //判斷連線狀態
        {
            get
            {
                return serialPort1?.IsOpen ?? false;    //"?"讓後面變數變成可null,"??"是否為null,是=false,否=當下的值
            }
        }        
        private void CommandCombine(int item)     //指令組合
        {
            byte[] CommandListTransfer;
            byte[] chksum;
            switch (item)
            {
                case 0:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x51);
                    CommandList.Add(0x00);
                    CommandList.Add(0x51);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    Thread.Sleep(200);
                    CommandList.Clear();
                    Array.Clear(CommandListTransfer, 0, CommandListTransfer.Length);
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x53);
                    CommandList.Add(0x00);
                    CommandList.Add(0x53);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case 1:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x51);
                    CommandList.Add(0x00);
                    CommandList.Add(0x51);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case 2:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x04);
                    CommandList.Add(0x50);
                    CommandList.Add(Convert.ToByte(Convert.ToInt16(textBox2.Text)));
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case 3:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x53);
                    CommandList.Add(0x00);
                    CommandList.Add(0x53);
                    CommandListTransfer = CommandList.ToArray();
                    IDorSN = true;
                    SendCommand(CommandListTransfer);
                    break;
                case 4:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x07);
                    CommandList.Add(0x52);
                    int textBox2Transfer1 = Convert.ToInt32(textBox2.Text, 16);
                    byte[] textBox2Transfer2 = BitConverter.GetBytes(textBox2Transfer1);
                    Array.Reverse(textBox2Transfer2);
                    CommandList.AddRange(textBox2Transfer2);
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case 5:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x04);
                    CommandList.Add(0x50);
                    CommandList.Add(Convert.ToByte(Convert.ToInt16(TBCSetIDTB.Text)));
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    TBCSetIDTB.Clear();
                    break;
                case 6:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x07);
                    CommandList.Add(0x52);
                    int TBCSetSNTBTransfer1 = Convert.ToInt32(TBCSetSNTB.Text, 16);
                    byte[] TBCSetSNTBTransfer2 = BitConverter.GetBytes(TBCSetSNTBTransfer1);
                    Array.Reverse(TBCSetSNTBTransfer2);
                    CommandList.AddRange(TBCSetSNTBTransfer2);
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    TBCSetSNTB.Clear();
                    break;
                case 7:
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x04);
                    CommandList.Add(0x00);
                    CommandList.Add(0x01);
                    CommandList.Add(0x00);
                    CommandList.Add(0x01);
                    CommandListTransfer = CommandList.ToArray();
                    IsBAT = true;
                    SendCommand(CommandListTransfer);
                    break;
                //case 8:                   
                //    CommandList.Clear();
                //    CommandList.Add(0xFA);
                //    CommandList.Add(0xBA);
                //    CommandList.Add(0x04);
                //    CommandList.Add(0x00);
                //    CommandList.Add(0x01);
                //    CommandList.Add(0x00);
                //    CommandList.Add(0x01);
                //    CommandListTransfer = CommandList.ToArray();
                //    IsBAT = true;
                //    UpdatePeriod = true;
                //    SendCommand(CommandListTransfer);                  
                //    break;
                //case 9:
                //    CommandList.Clear();
                //    CommandList.Add(0xFA);
                //    CommandList.Add(0xBA);
                //    CommandList.Add(0x04);
                //    CommandList.Add(0x00);
                //    CommandList.Add(0x00);
                //    CommandList.Add(0x00);
                //    CommandList.Add(0x00);
                //    CommandListTransfer = CommandList.ToArray();
                //    IsBAT = true;
                //    SendCommand(CommandListTransfer);
                //    break;
            }
        }
        private uint CalculateChkSum(List<byte> buf,char length)     //計算checksum
        {
            buf = buf.GetRange(3, buf.Count - 3);
            uint ChkSum = 0;
            char ChkLen;
            int n;
            ChkLen = length;
            for (n = 0; n < ChkLen - 1; n += 2)
            {
                ChkSum += (uint)((buf[n] << 8) | buf[n + 1]);
            }
            if ((length & 0x01) == 1)
            {
                ChkSum = ChkSum ^ buf[length - 1];
            }
            return ChkSum;
        }

        //以下是TabControl
        private void TBCCOMPort_SelectedIndexChanged(object sender, EventArgs e)     //設定COMPort
        {
            serialPort1.PortName = (string)TBCCOMPort.SelectedItem;
        }

        private void TBCBaudRate_SelectedIndexChanged(object sender, EventArgs e)     //設定BaudRate
        {
            serialPort1.BaudRate = Convert.ToInt32(TBCBaudRate.SelectedItem);
        }

        private void TBCButton_Click(object sender, EventArgs e)     //與電池連線
        {
            if (Connected)
            {
                serialPort1.Close();
                TBCButton.BackColor = Color.GreenYellow;
                TBCButton.Text = "Connect";
            }
            else
            {
                try
                {
                    if(TBCCOMPort.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else if(TBCBaudRate.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else
                    {
                        serialPort1.Open();
                        TBCButton.BackColor = Color.Pink;
                        TBCButton.Text = "Disconnect";
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Connecting failed");
                }
            }
        }

        private void TBCGetID_Click(object sender, EventArgs e)     //讀取一次ID
        {
            CommandCombine(1);
        }

        private void TBCClear_Click(object sender, EventArgs e)     //清除ID
        {
            TBCID.Clear();
            TBCIDTrans.Clear();
        }

        private void TBCSetID_Click(object sender, EventArgs e)     //set ID
        {
            try
            {
                if (Convert.ToInt32(TBCSetIDTB.Text) > 255)
                {
                    MessageBox.Show("請輸入0-255");
                }
                else if (Convert.ToInt32(TBCSetIDTB.Text) < 0)
                {
                    MessageBox.Show("請輸入0-255");
                }
                else
                {
                    CommandCombine(5);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("請輸入0-255");
            }
        }

        private void TBCGetSN_Click(object sender, EventArgs e)     //讀取一次SN
        {
            CommandCombine(3);
        }

        private void TBCClear2_Click(object sender, EventArgs e)     //清除SN
        {
            TBCSN.Clear();
            TBCSNTrans.Clear();
        }

        private void tabPageLocking()     //持續讀取時，鎖住tabPage4
        {
            while (true)
            {
                if (TBCUpdatePeriod.BackColor == Color.Pink)
                {
                    tabControl.SelectedTab = tabPage4;                    
                }
                else
                {                    
                    try
                    {
                        if (ThdLockPage.IsAlive)
                        {
                            ThdLockPage.Abort();
                        }
                    }
                    catch (ThreadAbortException ex)
                    {
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("執行緒錯誤!!");
                    }
                }
                Thread.Sleep(10);
            }
        }        
        private void TBCSetSN_Click(object sender, EventArgs e)     //set SN
        {
            try
            {                
                //if (TBCSetIDTB.Text.Length == 8)
                //{
                //    if(int.TryParse())
                //}
                if (TBCSetSNTB.Text.Length > 8)     //可以再優化
                {
                    MessageBox.Show("請輸入8位正整數");
                }
                else if (TBCSetSNTB.Text.Length < 8)     //可以再優化
                {
                    MessageBox.Show("請輸入8位正整數");
                }
                else
                {
                    CommandCombine(6);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("請輸入8位正整數");
            }
        }

        private void TBCGetBAT_Click(object sender, EventArgs e)     //讀取一次電池資訊
        {
            CommandCombine(7);
        }
        public Int32 HexToDec(string HexString)     //16進制轉10進制
        {
            return (short.Parse(HexString, System.Globalization.NumberStyles.HexNumber));
        }

        private void TBCUpdatePeriod_Click(object sender, EventArgs e)     //持續讀取0x00資料
        {
            if(TBCUpdatePeriod.BackColor == Color.GreenYellow)     //開始持續讀取
            {
                TBCUpdatePeriod.BackColor = Color.Pink;
                TBCUpdatePeriod.Text = "Stop";
                ThdUpdatePeriod.Start();
            }
            else     //結束持續讀取
            {
                try
                {
                    TBCUpdatePeriod.BackColor = Color.GreenYellow;
                    TBCUpdatePeriod.Text = "Update period";
                    if (ThdUpdatePeriod.IsAlive)
                    {
                        ThdUpdatePeriod.Abort();
                    }
                }
                catch (ThreadAbortException ex)
                {
                }
                catch (Exception ex)
                {
                    MessageBox.Show("執行緒錯誤!!");
                }
            }
        }
        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)     //鎖定頁面
        {
            if (tabControl.SelectedTab == tabPage4)
            {
                ThdLockPage.Start();
            }
        }
        private void BatUpdatePeriod()     //持續讀取的執行緒
        {
            while(true)
            {
                CommandCombine(7);
                Thread.Sleep(1000);
            }
        }
    }
}
