﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            //DateTime date = new DateTime(2019, 07, 09, 17, 00, 00);
            //DateTime BaseTime = new DateTime(1970, 01, 01, 00, 00, 00);
            //TimeSpan Time = date.Subtract(BaseTime);
            //long TimeSec = Convert.ToInt64(Time.TotalSeconds);
            //byte[] TimeArray = BitConverter.GetBytes(TimeSec);            
            //Console.WriteLine("OK");
            //Console.ReadLine();


            //List<byte> buf = new List<byte> { 0xFA, 0xBA, 0x0B, 0x21, 0x00, 0x00, 0x00, 0x00, 0x5D, 0x24, 0xC8, 0x10 };
            //buf = buf.GetRange(3, buf.Count - 3);
            //uint ChkSum = 0;
            //char ChkLen;
            //int n;
            //ChkLen = (char)9;
            //for (n = 0; n < ChkLen - 1; n += 2)
            //{
            //    ChkSum += (uint)((buf[n] << 8) | buf[n + 1]);
            //}
            //if (((char)9 & 0x01) == 1)
            //{
            //    ChkSum = ChkSum ^ buf[9 - 1];
            //}
            //byte[] tmp = BitConverter.GetBytes(ChkSum);
            //Console.WriteLine("OK");
            //Console.ReadLine();


            //DateTime BaseTime = new DateTime(1970, 01, 01, 00, 00, 00);
            //DateTime tmp = BaseTime.AddSeconds(1562691600);
            //Console.WriteLine(tmp.ToString("yyyy-MM-dd HH:mm:ss"));
            //Console.ReadLine();
        }
    }
}
