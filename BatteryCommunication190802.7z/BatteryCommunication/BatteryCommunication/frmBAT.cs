﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace BatteryCommunication
{
    public partial class frmBAT : Form
    {

        private Queue<string> BATLog = new Queue<string>();
        private List<byte> CommandList = new List<byte>();
        private Thread ThdLockPage;
        private Thread ThdUpdatePeriod;
        private Thread ThdWriteLog;
        private Thread ThdNowTime;        

        private bool IDorSN = false;
        private bool IsBAT = false;
        private bool IsTP01 = false;
        private bool UpdatePeriod = false;

        public frmBAT()
        {
            InitializeComponent();

            ThdLockPage = new Thread(tabPageLocking);
            ThdUpdatePeriod = new Thread(BatUpdatePeriod);
            ThdWriteLog = new Thread(WriteExLog);
            ThdNowTime = new Thread(ReadNowTime);
            ThdWriteLog.Start();
            ThdNowTime.Start();
            ThdLockPage.IsBackground = true;
            ThdUpdatePeriod.IsBackground = true;
            ThdWriteLog.IsBackground = true;
            ThdNowTime.IsBackground = true;

            TBCButton.BackColor = Color.GreenYellow;
            TBCUpdatePeriod.BackColor = Color.GreenYellow;
            
            string[] PortNames = SerialPort.GetPortNames();
            TBCCOMPort.Items.AddRange(PortNames);
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(PortReply);

        }             
        private void PortReply(object sender,SerialDataReceivedEventArgs e)     //SerialPort讀取到的資料處理
        {
            byte[] PortData = new byte[1024];
            Thread.Sleep(50);
            int size = serialPort1.Read(PortData, 0, 1024);            
            if (IDorSN == false & IsBAT == false)
            {
                TBCID.Invoke(new EventHandler(delegate
                {
                    TBCID.Clear();
                    TBCID.AppendText(BitConverter.ToString(PortData, 0, size).Replace('-', ' '));
                }));
                TBCIDTrans.Invoke(new EventHandler(delegate
                {
                    TBCIDTrans.Clear();
                    TBCIDTrans.AppendText(BitConverter.ToString(PortData, 4, 1).Replace('-', ' '));
                }));
            }
            else if (IsBAT == true)
            {
                if (IsTP01 == true)
                {
                    TBCFV.Invoke(new EventHandler(delegate
                    {
                        TBCFV.Clear();
                        string BATFV = (BitConverter.ToString(PortData, 5, 1).Replace('-', ' '));
                        TBCFV.AppendText(BATFV);
                    }));
                    TBCBATTime.Invoke(new EventHandler(delegate
                    {
                        TBCBATTime.Clear();
                        string BATTime = $"{(BitConverter.ToString(PortData, 17, 1))}{(BitConverter.ToString(PortData, 16, 1))}" +
                        $"{(BitConverter.ToString(PortData, 15, 1))}{(BitConverter.ToString(PortData, 14, 1))}" +
                        $"{(BitConverter.ToString(PortData, 13, 1))}{(BitConverter.ToString(PortData, 12, 1))}" +
                        $"{(BitConverter.ToString(PortData, 11, 1))}{(BitConverter.ToString(PortData, 10, 1))}";
                        long BATTimeTrans = HexToDec(BATTime);
                        DateTime tmp = CalculateTime(BATTimeTrans);
                        TBCBATTime.Text = tmp.ToString("yyyy-MM-dd HH:mm:ss");
                    }));
                    IsBAT = false;
                    IsTP01 = false;
                }
                else
                {
                    TBCCE.Invoke(new EventHandler(delegate
                    {
                        TBCCE.Clear();
                        string BATCE = (BitConverter.ToString(PortData, 5, 1) + BitConverter.ToString(PortData, 4, 1));
                        double BATCETrans = (Convert.ToDouble(HexToDec(BATCE))) * 0.01;
                        TBCCE.AppendText(Convert.ToString(BATCETrans));
                    }));
                    TBCCD.Invoke(new EventHandler(delegate
                    {
                        TBCCD.Clear();
                        string BATCD = (BitConverter.ToString(PortData, 7, 1) + BitConverter.ToString(PortData, 6, 1));
                        double BATCDTrans = (Convert.ToDouble(HexToDec(BATCD))) * 0.01;
                        TBCCD.AppendText(Convert.ToString(BATCDTrans));
                    }));
                    TBCPV.Invoke(new EventHandler(delegate
                    {
                        TBCPV.Clear();
                        string BATPV = (BitConverter.ToString(PortData, 9, 1) + BitConverter.ToString(PortData, 8, 1));
                        double BATPVTrans = (Convert.ToDouble(HexToDec(BATPV))) * 0.001;
                        TBCPV.AppendText(Convert.ToString(BATPVTrans));
                    }));
                    TBCSF.Invoke(new EventHandler(delegate
                    {
                        TBCSF.Clear();
                        string BATSF = (BitConverter.ToString(PortData, 11, 1) + BitConverter.ToString(PortData, 10, 1));
                        TBCSF.AppendText(BATSF);
                    }));
                    TBCEF.Invoke(new EventHandler(delegate
                    {
                        TBCEF.Clear();
                        string BATEF = (BitConverter.ToString(PortData, 13, 1) + BitConverter.ToString(PortData, 12, 1));
                        TBCEF.AppendText(BATEF);
                    }));
                    IsBAT = false;
                }
            }
            else
            {
                string SN_ASCII;
                TBCSN.Invoke(new EventHandler(delegate
                {
                    TBCSN.Clear();
                    TBCSN.AppendText(BitConverter.ToString(PortData, 0, size).Replace('-', ' '));
                }));
                TBCSNTrans.Invoke(new EventHandler(delegate
                {
                    TBCSNTrans.Clear();
                    SN_ASCII = BitConverter.ToString(PortData, 4, 4).Replace('-', ' ');
                    TBCSNTrans.AppendText(HexStringToASCII(SN_ASCII));
                    //TBCSNTrans.AppendText(BitConverter.ToString(PortData, 4, 4).Replace('-', ' '));
                }));
                IDorSN = false;
            }
            
        }                       
        private void SendCommand(byte[] Cmd)     //傳送指令
        {
            if(Connected != false)
            {
                serialPort1.Write(Cmd,0,Cmd.Length);
            }
            else
            {
                MessageBox.Show("Not Connected!!!");
            }
        }
        public bool Connected     //判斷連線狀態
        {
            get
            {
                return serialPort1?.IsOpen ?? false;    //"?"讓後面變數變成可null,"??"是否為null,是=false,否=當下的值
            }
        }        

        public enum CommandKind     //指令種類列舉
        {
            GetID,
            GetSN,
            SetID,
            SetSN,
            GetBAT00,
            GetBAT01,
            SetNowTime,
            SetTime
        }
        private void CommandCombine(CommandKind item)     //指令組合
        {
            byte[] CommandListTransfer;
            byte[] chksum;
            byte[] Time;
            switch (item)
            {
                case CommandKind.GetID:     //取得電池ID
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x51);
                    CommandList.Add(0x00);
                    CommandList.Add(0x51);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;                
                case CommandKind.GetSN:     //取得電池序號
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x03);
                    CommandList.Add(0x53);
                    CommandList.Add(0x00);
                    CommandList.Add(0x53);
                    CommandListTransfer = CommandList.ToArray();
                    IDorSN = true;
                    SendCommand(CommandListTransfer);
                    break;                
                case CommandKind.SetID:     //設定電池ID
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x04);
                    CommandList.Add(0x50);
                    CommandList.Add(Convert.ToByte(Convert.ToInt16(TBCSetIDTB.Text)));
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    TBCSetIDTB.Clear();
                    break;
                case CommandKind.SetSN:     //設定電池序號
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x07);
                    CommandList.Add(0x52);
                    int TBCSetSNTBTransfer1 = Convert.ToInt32(HexStringTrim, 16);
                    byte[] TBCSetSNTBTransfer2 = BitConverter.GetBytes(TBCSetSNTBTransfer1);
                    Array.Reverse(TBCSetSNTBTransfer2);
                    CommandList.AddRange(TBCSetSNTBTransfer2);
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    TBCSetSNTB.Clear();
                    break;
                case CommandKind.GetBAT00:     //取得Type 0x00 電池基本資訊
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x04);
                    CommandList.Add(0x00);
                    CommandList.Add(0x01);
                    CommandList.Add(0x00);
                    CommandList.Add(0x01);
                    CommandListTransfer = CommandList.ToArray();
                    IsBAT = true;
                    SendCommand(CommandListTransfer);
                    break;
                case CommandKind.GetBAT01:     //取得Type 0x010 電池基本資訊
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x04);
                    CommandList.Add(0x01);
                    CommandList.Add(0x01);
                    CommandList.Add(0x01);
                    CommandList.Add(0x01);
                    CommandListTransfer = CommandList.ToArray();
                    IsBAT = true;
                    IsTP01 = true;
                    SendCommand(CommandListTransfer);
                    break;
                case CommandKind.SetNowTime:     //Update Now time
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x0B);
                    CommandList.Add(0x21);
                    Time = TimeForSec(DateTime.Now);
                    CommandList.Add(Time[7]);
                    CommandList.Add(Time[6]);
                    CommandList.Add(Time[5]);
                    CommandList.Add(Time[4]);
                    CommandList.Add(Time[3]);
                    CommandList.Add(Time[2]);
                    CommandList.Add(Time[1]);
                    CommandList.Add(Time[0]);
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    break;
                case CommandKind.SetTime:     //Update time
                    CommandList.Clear();
                    CommandList.Add(0xFA);
                    CommandList.Add(0xBA);
                    CommandList.Add(0x0B);
                    CommandList.Add(0x21);
                    DateTime tmp = new DateTime(Convert.ToInt16(TBCYearTB.Text), Convert.ToInt16(TBCMonthTB.Text), Convert.ToInt16(TBCDayTB.Text),
                        Convert.ToInt16(TBCHourTB.Text), Convert.ToInt16(TBCMinTB.Text), Convert.ToInt16(TBCSecTB.Text));
                    Time = TimeForSec(tmp);
                    CommandList.Add(Time[7]);
                    CommandList.Add(Time[6]);
                    CommandList.Add(Time[5]);
                    CommandList.Add(Time[4]);
                    CommandList.Add(Time[3]);
                    CommandList.Add(Time[2]);
                    CommandList.Add(Time[1]);
                    CommandList.Add(Time[0]);
                    chksum = BitConverter.GetBytes(CalculateChkSum(CommandList, (char)(CommandList.Count - 3)));
                    CommandList.Add(chksum[1]);
                    CommandList.Add(chksum[0]);
                    CommandListTransfer = CommandList.ToArray();
                    SendCommand(CommandListTransfer);
                    TBCYearTB.Clear();
                    TBCMonthTB.Clear();
                    TBCDayTB.Clear();
                    TBCHourTB.Clear();
                    TBCMinTB.Clear();
                    TBCSecTB.Clear();
                    break;
                    //case 9:
                    //    CommandList.Clear();
                    //    CommandList.Add(0xFA);
                    //    CommandList.Add(0xBA);
                    //    CommandList.Add(0x04);
                    //    CommandList.Add(0x00);
                    //    CommandList.Add(0x00);
                    //    CommandList.Add(0x00);
                    //    CommandList.Add(0x00);
                    //    CommandListTransfer = CommandList.ToArray();
                    //    IsBAT = true;
                    //    SendCommand(CommandListTransfer);
                    //    break;
            }
        }
        private uint CalculateChkSum(List<byte> buf,char length)     //計算checksum
        {
            buf = buf.GetRange(3, buf.Count - 3);
            uint ChkSum = 0;
            char ChkLen;
            int n;
            ChkLen = length;
            for (n = 0; n < ChkLen - 1; n += 2)
            {
                ChkSum += (uint)((buf[n] << 8) | buf[n + 1]);
            }
            if ((length & 0x01) == 1)     //除2的意思
            {
                ChkSum = ChkSum ^ buf[length - 1];
            }
            return ChkSum;
        }        

        //以下是TabControl
        private void TBCCOMPort_SelectedIndexChanged(object sender, EventArgs e)     //設定COMPort
        {
            serialPort1.PortName = (string)TBCCOMPort.SelectedItem;
        }

        private void TBCBaudRate_SelectedIndexChanged(object sender, EventArgs e)     //設定BaudRate
        {
            serialPort1.BaudRate = Convert.ToInt32(TBCBaudRate.SelectedItem);
        }

        private void TBCButton_Click(object sender, EventArgs e)     //與電池連線
        {
            if (Connected)
            {
                serialPort1.Close();
                TBCButton.BackColor = Color.GreenYellow;
                TBCButton.Text = "Connect";
            }
            else
            {
                try
                {
                    if(TBCCOMPort.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else if(TBCBaudRate.SelectedIndex == -1)
                    {
                        MessageBox.Show("COM or Baud Rate not exist!!!");
                    }
                    else
                    {
                        serialPort1.Open();
                        TBCButton.BackColor = Color.Pink;
                        TBCButton.Text = "Disconnect";
                    }
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Connecting failed");
                }
            }
        }

        private void TBCGetID_Click(object sender, EventArgs e)     //讀取一次ID
        {
            CommandCombine(CommandKind.GetID);
        }

        private void TBCClear_Click(object sender, EventArgs e)     //清除ID
        {
            TBCID.Clear();
            TBCIDTrans.Clear();
        }

        private void TBCSetID_Click(object sender, EventArgs e)     //set ID
        {
            try
            {
                if (Convert.ToInt32(TBCSetIDTB.Text) > 255)
                {
                    MessageBox.Show("請輸入0-255");
                }
                else if (Convert.ToInt32(TBCSetIDTB.Text) < 0)
                {
                    MessageBox.Show("請輸入0-255");
                }
                else
                {
                    CommandCombine(CommandKind.SetID);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("請輸入0-255");
            }
        }

        private void TBCGetSN_Click(object sender, EventArgs e)     //讀取一次SN
        {
            CommandCombine(CommandKind.GetSN);
        }

        private void TBCClear2_Click(object sender, EventArgs e)     //清除SN
        {
            TBCSN.Clear();
            TBCSNTrans.Clear();
        }

        private void tabPageLocking()     //持續讀取時，鎖住tabPage4頁面
        {
            while (true)
            {
                tabControl.Invoke(new EventHandler(delegate
                {
                    tabControl.SelectedTab = tabPage4;
                }));
                Thread.Sleep(10);
            }
        }

        string HexString;
        string HexStringTrim;
        private void TBCSetSN_Click(object sender, EventArgs e)     //set SN
        {
            try
            {
                //if (TBCSetIDTB.Text.Length == 8)
                //{
                //    if(int.TryParse())
                //}

                byte[] ascii = System.Text.Encoding.Default.GetBytes(TBCSetSNTB.Text);
                int count = TBCSetSNTB.Text.Length;
                string[] HexTrans = new string[count];
                for (int size = 0; size < count; size++)
                {
                    HexTrans[size] = ascii[size].ToString("x2");
                }
                HexString = string.Join(" ", HexTrans);
                HexStringTrim = HexString.Replace(" ", "");
                if (HexStringTrim.Length > 8)     //可以再優化
                {
                    MessageBox.Show("請輸入4位ASCII");
                }
                else if (HexStringTrim.Length < 8)     //可以再優化
                {
                    MessageBox.Show("請輸入4位ASCII");
                }
                else
                {
                    CommandCombine(CommandKind.SetSN);
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("請輸入4位ASCII");
            }
        }

        private void TBCGetBAT_Click(object sender, EventArgs e)     //讀取一次0x00電池資訊
        {
            CommandCombine(CommandKind.GetBAT00);
        }

        private void TBCGetBAT01_Click(object sender, EventArgs e)     //讀取一次0x01電池資訊
        {
            CommandCombine(CommandKind.GetBAT01);
        }

        public long HexToDec(string HexString)     //16進制轉10進制
        {
            return (long.Parse(HexString, System.Globalization.NumberStyles.HexNumber));
        }

        private void TBCUpdatePeriod_Click(object sender, EventArgs e)     //持續讀取0x00資料
        {
            if(TBCUpdatePeriod.BackColor == Color.GreenYellow)     //開始持續讀取
            {
                TBCUpdatePeriod.BackColor = Color.Pink;
                TBCUpdatePeriod.Text = "Stop";

                TBCGetBAT.Enabled = false;          //鎖住其他傳指令按鍵
                TBCGetSN.Enabled = false;           //鎖住其他傳指令按鍵
                TBCSetSN.Enabled = false;           //鎖住其他傳指令按鍵
                TBCGetID.Enabled = false;           //鎖住其他傳指令按鍵
                TBCSetID.Enabled = false;           //鎖住其他傳指令按鍵
                TBCGetBAT01.Enabled = false;        //鎖住其他傳指令按鍵
                TBCGetTime.Enabled = false;         //鎖住其他傳指令按鍵
                TBCUpdateNow.Enabled = false;       //鎖住其他傳指令按鍵
                TBCUpdateTime.Enabled = false;      //鎖住其他傳指令按鍵

                ThdLockPage.Start();
                ThdUpdatePeriod.Start();
            }
            else     //結束持續讀取
            {
                try
                {
                    TBCUpdatePeriod.BackColor = Color.GreenYellow;
                    TBCUpdatePeriod.Text = "Update period";
                    if (ThdUpdatePeriod.IsAlive || ThdLockPage.IsAlive)
                    {
                        ThdUpdatePeriod.Abort();
                        ThdLockPage.Abort();
                    }
                }
                catch (ThreadAbortException ex)
                {
                }
                catch (Exception ex)
                {
                    MessageBox.Show("執行緒錯誤!!");
                }
                finally
                {
                    ThdLockPage = new Thread(tabPageLocking);
                    ThdUpdatePeriod = new Thread(BatUpdatePeriod);
                    ThdLockPage.IsBackground = true;
                    ThdUpdatePeriod.IsBackground = true;
                    TBCGetBAT.Enabled = true;
                    TBCGetSN.Enabled = true;
                    TBCSetSN.Enabled = true;
                    TBCGetID.Enabled = true;
                    TBCSetID.Enabled = true;
                    TBCGetBAT01.Enabled = true;
                    TBCGetTime.Enabled = true;
                    TBCUpdateNow.Enabled = true;
                    TBCUpdateTime.Enabled = true;
                }
            }
        }

        private void TBCGetTime_Click(object sender, EventArgs e)     //讀取電池時間
        {
            CommandCombine(CommandKind.GetBAT01);
        }

        private void TBCUpdateNow_Click(object sender, EventArgs e)     //Update 現在時間
        {
            CommandCombine(CommandKind.SetNowTime);
        }

        private void TBCUpdateTime_Click(object sender, EventArgs e)     //Update 自定義的時間
        {
            CommandCombine(CommandKind.SetTime);
        }

        //private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (tabControl.SelectedTab == tabPage4)
        //    {
        //        ThdLockPage.Start();
        //    }
        //}

        private void BatUpdatePeriod()     //持續讀取的執行緒
        {
            while(true)
            {
                CommandCombine(CommandKind.GetBAT00);
                Thread.Sleep(2000);
            }
        }

        private void ReadNowTime()     //讀取當下時間的執行緒
        {
            while(true)
            {
                DateTime Time = DateTime.Now;
                TBCNowTime.Invoke(new EventHandler(delegate
                {
                    TBCNowTime.Text = Time.ToString("yyyy-MM-dd HH:mm:ss");
                }));
                Thread.Sleep(50);
            }
        }

        private void LogQueue(string Log)     //Log放到Queue
        {
            try
            {
                BATLog.Enqueue(Log);                
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        
        private void WriteExLog()     //寫Log的執行緒
        {
            DateTime Start = DateTime.Now;
            DateTime End = DateTime.Now;
            double WriteTime = 0;
            while (true)
            {
                DateTime Date = DateTime.Now;
                string TodyMillisecond = Date.ToString("yyyy-MM-dd HH:mm:ss");
                string Tody = Date.ToString("yyyy-MM-dd");
                string LogPath = Environment.CurrentDirectory + "\\Log";
                try
                {
                    if (BATLog.Count >= 10 || WriteTime > 60)
                    {
                        if (!Directory.Exists(LogPath))
                        {
                            Directory.CreateDirectory(LogPath);     //新增資料夾
                        }
                        //把例外狀況寫到目的檔案，若檔案存在則附加在原本內容之後(換行)
                        File.AppendAllText(LogPath + Tody + ".txt", "\r\n" + TodyMillisecond + "：" + BATLog.ToArray());
                        BATLog.Clear();
                        Start = DateTime.Now;
                    }
                    End = DateTime.Now;
                    TimeSpan ts = End.Subtract(Start);     //時間相減
                    WriteTime = ts.Seconds;                   
                }
                catch (ThreadAbortException ex)
                {
                    if (!Directory.Exists(LogPath))
                    {
                        Directory.CreateDirectory(LogPath);
                    }
                    File.AppendAllText(LogPath + Tody + ".txt", "\r\n" + TodyMillisecond + "：" + BATLog.ToArray());
                    BATLog.Clear();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Thread.Sleep(50);
            }
        }

        public static byte[] HexStringToBinary(string hexstring)     //16進制轉2進制
        {
            try
            {
                string[] tmpary = hexstring.Trim().Split(' ');
                byte[] buff = new byte[tmpary.Length];
                for (int i = 0; i < buff.Length; i++)
                {
                    buff[i] = Convert.ToByte(tmpary[i], 16);
                }
                return buff;
            }
            catch (Exception ex)
            {
                byte[] error = new byte[5] { 69, 114, 114, 111, 114 };

                MessageBox.Show("數值間請加空白建區隔");
                return error;
            }
        }

        public static string HexStringToASCII(string hexstring)     //16進制轉ASCII
        {
            byte[] bt = HexStringToBinary(hexstring);
            string lin = "";
            for (int i = 0; i < bt.Length; i++)
            {
                lin = lin + bt[i] + " ";
            }


            string[] ss = lin.Trim().Split(new char[] { ' ' });
            char[] c = new char[ss.Length];
            int a;
            for (int i = 0; i < c.Length; i++)
            {
                a = Convert.ToInt32(ss[i]);
                c[i] = Convert.ToChar(a);
            }

            string b = new string(c);
            return b;
        }

        private DateTime CalculateTime(long seconds)
        {
            DateTime BaseTime = new DateTime(1970, 01, 01, 00, 00, 00);
            DateTime tmp = BaseTime.AddSeconds(seconds);
            return tmp;
            //int Day, Hour, Min, Sec = 0;
            //Sec = Convert.ToInt32(seconds % 60);
            //Min = Convert.ToInt32(seconds % 3600);
            //Day = Convert.ToInt32(seconds / 86400);
            //Hour = Convert.ToInt32(seconds - (Day * 86400));
            //TimeSpan ts = new TimeSpan(Day, Hour, Min, Sec);
        }

        private byte[] TimeForSec(DateTime date)
        {
            DateTime BaseTime = new DateTime(1970, 01, 01, 00, 00, 00);
            TimeSpan Time = date.Subtract(BaseTime);
            long TimeSec = Convert.ToInt64(Time.TotalSeconds);
            byte[] TimeArray = BitConverter.GetBytes(TimeSec);
            return TimeArray;
        }
    }
}
