﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO.Ports;

namespace BatterySimulator
{
    public partial class Form1 : Form
    {
        string[] Data = { "20180828", "63%", "50", "No" };
        string DataTransfer { get => string.Concat("ID : " + Data[0], "\r\nBattery : " + Data[1], "\r\nTemp : " + Data[2], "\r\nDocking : " + Data[3] + " (Y/N)\r\n");
        }


        public Form1()
        {
            InitializeComponent();

            textBox1.AppendText(DataTransfer);
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(PortReply);
            serialPort1.Open();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
        private void PortReply(object sender, SerialDataReceivedEventArgs e)
        {
            string CommandReceived = serialPort1.ReadExisting();
            if (CommandReceived == "1")
            {
                serialPort1.Write(DataTransfer);
            }
            else
            {
                Data[0] = CommandReceived;
                textBox1.Invoke(new EventHandler(delegate
                {
                    textBox1.Clear();
                    textBox1.AppendText(DataTransfer);
                }));                
                serialPort1.Write(DataTransfer);
            }
        }
    }
}
